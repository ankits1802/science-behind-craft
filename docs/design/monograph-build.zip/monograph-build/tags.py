import re
VOID={'area','base','br','col','embed','hr','img','input','link','meta','param','source','track','wbr'}
tag_re=re.compile(r'<(/?)([a-zA-Z][a-zA-Z0-9:-]*)((?:[^>"\']|"[^"]*"|\'[^\']*\')*?)(/?)>|<!--.*?-->',re.S)
def element_end(s,start):
    """start: index of '<' of an element start tag; return index after its matching end tag"""
    m=tag_re.match(s,start)
    assert m and not m.group(1), s[start:start+80]
    name=m.group(2).lower()
    if name in VOID or m.group(4): return m.end()
    if name in ('script','style','textarea','title'):
        e=s.lower().find('</'+name,m.end()); return s.find('>',e)+1
    depth=1; pos=m.end()
    while True:
        m2=tag_re.search(s,pos)
        if not m2: raise Exception('unclosed '+name+' at '+str(start))
        pos=m2.end()
        if m2.group(0).startswith('<!--'): continue
        n=m2.group(2).lower()
        if n in ('script','style','textarea','title') and not m2.group(1):
            e=s.lower().find('</'+n,pos); pos=s.find('>',e)+1; continue
        if n!=name: continue
        if m2.group(1): depth-=1
        elif not m2.group(4): depth+=1
        if depth==0: return m2.end()
def find_start(s,pattern,after=0):
    """pattern: regex matching inside a start tag, returns index of '<'"""
    m=re.compile(pattern).search(s,after)
    if not m: return -1
    return s.rfind('<',0,m.start()+1) if s[m.start()]!='<' else m.start()
def outer(s,pattern,after=0):
    i=find_start(s,pattern,after)
    if i<0: raise Exception('not found '+pattern)
    return s[i:element_end(s,i)], i
def children(s):
    """top-level child elements of an html fragment string (element inner)"""
    out=[];pos=0
    while True:
        m=tag_re.search(s,pos)
        if not m: break
        if m.group(0).startswith('<!--') or m.group(1): pos=m.end(); continue
        e=element_end(s,m.start()); out.append((m.start(),e)); pos=e
    return out
def inner(el):
    a=tag_re.match(el).end(); b=el.rfind('</'); return el[a:b]
