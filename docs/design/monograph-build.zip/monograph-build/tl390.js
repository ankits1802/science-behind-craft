const path = require('path');
const { chromium } = require('C:/dev/IIT/science-behind-craft/frontend/node_modules/playwright');
(async () => {
  const b = await chromium.launch();
  const p = await (await b.newContext({ viewport: { width: 390, height: 844 } })).newPage();
  await p.goto('file:///' + process.argv[2].split(path.sep).join('/'));
  await p.evaluate(() => document.querySelector('[data-comp="time"]').scrollIntoView());
  await p.waitForTimeout(800);
  const info = await p.evaluate(() => { const l = document.querySelectorAll('[data-comp="time"] .tl-li [data-ev], [data-comp="time"] .tl-li button'); return l.length; });
  const btns = await p.$$('[data-comp="time"] .tl-pick');
  let ok = 'no buttons';
  if (btns.length > 7) { await btns[7].click(); await p.waitForTimeout(500); ok = await p.evaluate(() => { const li = document.querySelectorAll('[data-comp="time"] .tl-li'); return Array.from(li).map(x => x.classList.contains('is-on') ? 1 : 0).join(''); }); }
  console.log('buttons', info, ok);
  await b.close();
})();
