import re

def strip_comments(css):
    out = []
    i = 0
    n = len(css)
    while i < n:
        c = css[i]
        if c in '"\'':
            j = i + 1
            while j < n and css[j] != c:
                if css[j] == '\\':
                    j += 1
                j += 1
            out.append(css[i:j + 1])
            i = j + 1
        elif css.startswith('/*', i):
            j = css.find('*/', i + 2)
            i = n if j < 0 else j + 2
        else:
            out.append(c)
            i += 1
    return ''.join(out)


def _match_brace(css, i):
    depth = 0
    n = len(css)
    while i < n:
        c = css[i]
        if c in '"\'':
            j = i + 1
            while j < n and css[j] != c:
                if css[j] == '\\':
                    j += 1
                j += 1
            i = j + 1
            continue
        if c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return i
        i += 1
    raise ValueError('unbalanced')


NESTED_AT = ('@media', '@supports', '@container', '@layer', '@document', '@scope')


def parse(css):
    nodes = []
    i = 0
    n = len(css)
    while i < n:
        while i < n and css[i] in ' \t\r\n;':
            i += 1
        if i >= n:
            break
        j = i
        while j < n and css[j] not in '{;':
            if css[j] in '"\'':
                q = css[j]
                j += 1
                while j < n and css[j] != q:
                    if css[j] == '\\':
                        j += 1
                    j += 1
            j += 1
        if j >= n:
            break
        prelude = css[i:j].strip()
        if css[j] == ';':
            nodes.append(('stmt', prelude, None))
            i = j + 1
            continue
        k = _match_brace(css, j)
        body = css[j + 1:k]
        if prelude.startswith('@'):
            name = prelude.split()[0].split('(')[0].lower()
            if name in NESTED_AT:
                nodes.append(('at', prelude, parse(body)))
            else:
                nodes.append(('atraw', prelude, body))
        else:
            nodes.append(('rule', prelude, body))
        i = k + 1
    return nodes


def split_selectors(sel):
    parts = []
    depth = 0
    cur = ''
    for ch in sel:
        if ch in '([':
            depth += 1
        elif ch in ')]':
            depth -= 1
        if ch == ',' and depth == 0:
            parts.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        parts.append(cur.strip())
    return parts


ROOT_RE = re.compile(r'^(?::root|html)((?:\[[^\]]*\]|:not\([^)]*\)|:where\([^)]*\)|:is\([^)]*\))*)')


def scope_selector(sel, scope, idmap, classmap):
    s = sel.strip()
    for a, b in classmap:
        s = re.sub(r'\.' + re.escape(a) + r'(?![\w-])', '.' + b, s)
    if idmap:
        s = re.sub(r'#([A-Za-z_][\w-]*)', lambda m: '#' + idmap.get(m.group(1), m.group(1)), s)
    m = ROOT_RE.match(s)
    if m:
        rest = s[m.end():].strip()
        prefix = ':root' + m.group(1)
        if not rest:
            return prefix + ' ' + scope
        if rest.startswith('body'):
            rest = rest[4:].strip()
            if not rest:
                return prefix + ' ' + scope
            if rest[0] in '[.:#':
                return None
        return prefix + ' ' + scope + ' ' + rest
    if re.match(r'^body(?![\w-])', s):
        rest = s[4:].strip()
        if not rest:
            return None
        if rest[0] in '[.:#':
            return None
        return scope + ' ' + rest
    if s.startswith('*') and (len(s) == 1 or s[1] in ' :,'):
        return scope + ' ' + s + ', ' + scope if len(s) == 1 else scope + ' ' + s
    return scope + ' ' + s


def serialize(nodes, transform_rule, transform_at=None, indent=''):
    out = []
    for kind, prelude, body in nodes:
        if kind == 'stmt':
            continue
        if kind == 'rule':
            r = transform_rule(prelude, body)
            if r:
                out.append(r)
        elif kind == 'at':
            inner = serialize(body, transform_rule, transform_at)
            if inner.strip():
                out.append(prelude + '{' + inner + '}')
        else:
            r = transform_at(prelude, body) if transform_at else prelude + '{' + body + '}'
            if r:
                out.append(r)
    return '\n'.join(out)


def decls(body):
    out = []
    depth = 0
    cur = ''
    q = None
    for ch in body:
        if q:
            cur += ch
            if ch == q:
                q = None
            continue
        if ch in '"\'':
            q = ch
            cur += ch
            continue
        if ch == '(':
            depth += 1
        elif ch == ')':
            depth -= 1
        if ch == ';' and depth == 0:
            if cur.strip():
                out.append(cur.strip())
            cur = ''
        else:
            cur += ch
    if cur.strip():
        out.append(cur.strip())
    res = []
    for d in out:
        if ':' in d:
            k, v = d.split(':', 1)
            res.append((k.strip(), v.strip()))
    return res


def selector_classes(sel):
    sel = re.sub(r':(?:not|is|where|has)\(', ' (', sel)
    return re.findall(r'\.([A-Za-z_][\w-]*)', sel)


def selector_tags(sel):
    sel = re.sub(r'\[[^\]]*\]', '', sel)
    sel = re.sub(r'\([^)]*\)', '', sel)
    return re.findall(r'(?:^|[\s>+~(])([a-z][a-z0-9-]*)', sel)
