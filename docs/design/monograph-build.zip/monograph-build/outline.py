import re,sys
from html.parser import HTMLParser
p=sys.argv[1]
s=open(p,encoding='utf-8').read()
print("LEN",len(s))
# styles and scripts
for m in re.finditer(r'<(style|script)([^>]*)>(.*?)</\1>',s,re.S):
    print(m.group(1),m.group(2)[:80],len(m.group(3)),'@',m.start())
for m in re.finditer(r'<link[^>]*>',s): print(m.group(0)[:200])
class P(HTMLParser):
    def __init__(s):
        super().__init__(); s.depth=0; s.stack=[]; s.intext=None; s.buf=''
    def handle_starttag(s,t,a):
        a=dict(a)
        void=t in ('img','br','meta','link','input','hr','source','path','circle','rect','line','use','stop','ellipse','polygon','polyline')
        if t in ('section','header','main','article','nav','aside','footer') or (t=='div' and s.depth<4) or t in('h1','h2','h3'):
            print('  '*s.depth+f"<{t} id={a.get('id')} class={(a.get('class') or '')[:60]}> @{s.getpos()[0]}")
        if t in('h1','h2','h3'): s.intext=t; s.buf=''
        if not void: s.depth+=1; s.stack.append(t)
    def handle_endtag(s,t):
        if t in('h1','h2','h3') and s.intext==t:
            print('  '*s.depth+'   TEXT: '+re.sub(r'\s+',' ',s.buf)[:120]); s.intext=None
        if s.stack and t in s.stack:
            while s.stack:
                x=s.stack.pop(); s.depth-=1
                if x==t: break
    def handle_data(s,d):
        if s.intext: s.buf+=d
body=s[s.find('<body'):]
body=re.sub(r'<script.*?</script>','',body,flags=re.S)
body=re.sub(r'<style.*?</style>','',body,flags=re.S)
body=re.sub(r'<svg.*?</svg>','<svg/>',body,flags=re.S)
P().feed(body)
