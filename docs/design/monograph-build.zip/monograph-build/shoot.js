const path = require('path');
const { chromium } = require('C:/dev/IIT/science-behind-craft/frontend/node_modules/playwright');
const file = 'file:///' + process.argv[2].split(path.sep).join('/');
const outDir = process.argv[3];
const runs = (process.argv[4] || '1440-light,390-light,1440-dark').split(',');
const prefix = process.argv[5] || 'complete';
(async () => {
  const browser = await chromium.launch();
  for (const run of runs) {
    const [w, scheme] = run.split('-');
    const width = +w, height = width < 600 ? 844 : 900;
    const ctx = await browser.newContext({ viewport: { width, height }, colorScheme: scheme === 'dark' ? 'dark' : 'light', deviceScaleFactor: 1 });
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push('pageerror: ' + e.message));
    page.on('console', m => { if (m.type() === 'error') errs.push('console: ' + m.text()); });
    await page.goto(file, { waitUntil: 'load' });
    await page.evaluate(() => document.fonts && document.fonts.ready);
    await page.waitForTimeout(800);
    const total = await page.evaluate(() => document.documentElement.scrollHeight);
    const sw = await page.evaluate(() => document.documentElement.scrollWidth);
    let i = 0;
    for (let y = 0; y < total; y += height) {
      await page.evaluate(yy => window.scrollTo(0, yy), y);
      await page.waitForTimeout(450);
      await page.screenshot({ path: path.join(outDir, `${prefix}-${run}-${String(i).padStart(2, '0')}.png`) });
      i++;
    }
    const overflow = await page.evaluate(() => {
      const out = []; const vw = document.documentElement.clientWidth;
      document.querySelectorAll('body *').forEach(el => {
        const r = el.getBoundingClientRect();
        if (r.width && r.right > vw + 1 && getComputedStyle(el).position !== 'fixed') {
          const p = el.parentElement; const pr = p && p.getBoundingClientRect();
          if (!pr || pr.right <= vw + 1) out.push((typeof el.className === 'string' ? el.className : el.tagName) + ' ' + Math.round(r.right));
        }
      });
      return out.slice(0, 25);
    });
    console.log(run, 'height', total, 'scrollWidth', sw, 'shots', i);
    console.log('overflow', JSON.stringify(overflow));
    console.log(errs.slice(0, 20).join('\n'));
    await ctx.close();
  }
  await browser.close();
})();
