import re
import cssx

ROOT_ATTR = re.compile(r'^\[(?:data-theme|data-high-contrast|data-reduced-motion|data-larger-text)')
GLOBAL_PAT = re.compile(r'(?:^|[\s,>+~(])\.(?:pop|pop-[\w-]+|scrim)(?![\w-])')


def tokens_decls(tokens_css):
    pairs = set()
    for kind, sel, body in cssx.parse(cssx.strip_comments(tokens_css)):
        if kind == 'rule':
            for k, v in cssx.decls(body):
                pairs.add((k, re.sub(r'\s+', ' ', v)))
        elif kind == 'at':
            for k2, sel2, body2 in body:
                if k2 == 'rule':
                    for k, v in cssx.decls(body2):
                        pairs.add((k, re.sub(r'\s+', ' ', v)))
    return pairs


class Scoper:
    def __init__(self, board, idfix, aids, universe, token_pairs, classmap=(('cite', 'kcite'),)):
        self.board = board
        self.scope = '.bx-' + board
        self.idfix = idfix
        self.aids = aids
        self.universe = universe
        self.token_pairs = token_pairs
        self.classmap = list(classmap)
        self.keyframes = {}
        self.dropped = 0
        self.kept = 0
        self.globals = []

    def fix_ids(self, sel):
        def rep(m):
            i = m.group(1)
            if i in self.aids and i not in self.idfix.get('elements', set()):
                return '[data-aid="%s"]' % i
            if i in self.idfix.get('prefixed', set()):
                return '#%s-%s' % (self.board, i)
            return '#' + i
        return re.sub(r'#([A-Za-z_][\w-]*)', rep, sel)

    def used(self, sel):
        if self.universe is None:
            return True
        s2 = re.sub(r':not\([^)]*\)', '', sel)
        for c in cssx.selector_classes(s2):
            if c == 'kcite' or c == 'cite':
                continue
            if c not in self.universe:
                return False
        return True

    def scope_sel(self, sel):
        s = sel.strip()
        for a, b in self.classmap:
            s = re.sub(r'\.' + re.escape(a) + r'(?![\w-])', '.' + b, s)
        s = self.fix_ids(s)
        m = cssx.ROOT_RE.match(s)
        if not m and ROOT_ATTR.match(s):
            j = 0
            while j < len(s) and s[j] == '[':
                j = s.index(']', j) + 1
            prefix = ':root' + s[:j]
            rest = s[j:].strip()
            return prefix + ' ' + self.scope + (' ' + rest if rest else '')
        r = cssx.scope_selector(s, self.scope, None, [])
        return r

    def rule(self, sel, body):
        sels = cssx.split_selectors(sel)
        is_rootish = all(cssx.ROOT_RE.match(x.strip()) and not cssx.ROOT_RE.sub('', x.strip()).strip() for x in sels)
        if is_rootish:
            ds = cssx.decls(body)
            keep = [(k, v) for k, v in ds if not (k.startswith('--') and (k, re.sub(r'\s+', ' ', v)) in self.token_pairs)]
            keep = [(k, v) for k, v in keep if k.startswith('--') or k in ('color-scheme',)]
            if not keep:
                self.dropped += 1
                return None
            body = '; '.join('%s: %s' % kv for kv in keep)
        out = []
        for x in sels:
            if not self.used(x):
                continue
            r = self.scope_sel(x)
            if r:
                out.append(r)
        if not out:
            self.dropped += 1
            return None
        self.kept += 1
        body = self.fix_anim(body)
        return ', '.join(out) + '{' + body + '}'

    def fix_anim(self, body):
        if 'animation' not in body:
            return body

        def rep(m):
            k, v = m.group(1), m.group(2)
            for name in sorted(self.keyframes, key=len, reverse=True):
                v = re.sub(r'(?<![\w-])' + re.escape(name) + r'(?![\w-])', self.keyframes[name], v)
            return k + ':' + v
        return re.sub(r'(animation(?:-name)?)\s*:([^;]*)', rep, body)

    def at(self, prelude, body):
        name = prelude.split()[0].lower()
        if name in ('@keyframes', '@-webkit-keyframes'):
            kn = prelude.split()[1]
            return '%s %s{%s}' % (name, self.keyframes.get(kn, kn), body)
        if name == '@font-face' or name == '@property':
            self.globals.append(prelude + '{' + body + '}')
            return None
        return prelude + '{' + body + '}'

    def run(self, css):
        css = cssx.strip_comments(css)
        nodes = cssx.parse(css)

        def collect(ns):
            for k, p, b in ns:
                if k == 'atraw' and p.split()[0].lower() in ('@keyframes', '@-webkit-keyframes'):
                    kn = p.split()[1]
                    self.keyframes[kn] = self.board + '-' + kn
                elif k == 'at':
                    collect(b)
        collect(nodes)
        return cssx.serialize(nodes, self.rule, self.at)


def global_pop_css(css):
    css = cssx.strip_comments(css)
    nodes = cssx.parse(css)
    out = []

    def walk(ns, wrap=None):
        for k, p, b in ns:
            if k == 'rule':
                sels = [x for x in cssx.split_selectors(p) if GLOBAL_PAT.search(' ' + x) and '.phone' not in x and 'board' not in x]
                if sels:
                    sels = [re.sub(r'\.cite(?![\w-])', '.kcite', x) for x in sels]
                    r = ', '.join(sels) + '{' + b + '}'
                    out.append(wrap + '{' + r + '}' if wrap else r)
            elif k == 'at':
                walk(b, p)
            elif k == 'atraw' and p.split()[0] == '@keyframes' and p.split()[1] in ('kv-pop-in', 'kv-sheet-in', 'kv-press'):
                out.append(p + '{' + b + '}')
    walk(nodes)
    return '\n'.join(out)
