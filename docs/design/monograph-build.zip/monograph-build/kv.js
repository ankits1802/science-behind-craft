(function () {
  'use strict';
  var root = document.documentElement;
  var mq = window.matchMedia ? window.matchMedia('(prefers-reduced-motion: reduce)') : { matches: false };
  function reduced() { return mq.matches || root.getAttribute('data-reduced-motion') === 'true'; }
  function store(k, v) { try { if (v == null || v === '') localStorage.removeItem(k); else localStorage.setItem(k, v); } catch (e) {} }
  function esc(s) { return String(s == null ? '' : s).replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }
  function arr(x) { return Array.prototype.slice.call(x || []); }
  function $(s, c) { return (c || document).querySelector(s); }
  function $$(s, c) { return arr((c || document).querySelectorAll(s)); }
  var KV = window.KV = {};
  KV.reduced = reduced;

  KV.near = function (el, fn, margin) {
    if (!el) return;
    if (!('IntersectionObserver' in window)) { fn(); return; }
    var done = false;
    var o = new IntersectionObserver(function (es) {
      es.forEach(function (e) { if (e.isIntersecting && !done) { done = true; o.disconnect(); fn(); } });
    }, { rootMargin: (margin || 900) + 'px 0px' });
    o.observe(el);
  };

  KV.scope = function (key) {
    var pre = key + '-';
    function roots() { return $$('.bx-' + key); }
    function fix(sel) {
      return String(sel).replace(/#([A-Za-z_][\w-]*)/g, function (m, id) { return ':is(#' + id + ',#' + pre + id + ',[data-aid="' + id + '"])'; });
    }
    function byId(id) {
      var rs = roots();
      for (var i = 0; i < rs.length; i++) {
        var x = rs[i].querySelector('[id="' + pre + id + '"]') || rs[i].querySelector('[id="' + id + '"]') || rs[i].querySelector('[data-aid="' + id + '"]');
        if (x) return x;
      }
      return null;
    }
    function qs(sel) {
      var f = fix(sel), rs = roots();
      for (var i = 0; i < rs.length; i++) { var x = rs[i].querySelector(f); if (x) return x; }
      return null;
    }
    function qsa(sel) {
      var f = fix(sel), out = [];
      roots().forEach(function (r) { Array.prototype.push.apply(out, arr(r.querySelectorAll(f))); });
      return out;
    }
    var api = { getElementById: byId, querySelector: qs, querySelectorAll: qsa, getElementsByClassName: function (c) { return qsa('.' + c); } };
    return new Proxy(document, {
      get: function (t, p) {
        if (Object.prototype.hasOwnProperty.call(api, p)) return api[p];
        var v = t[p];
        return typeof v === 'function' ? v.bind(t) : v;
      }
    });
  };

  KV.boot = function (key, fn) {
    var rs = $$('.bx-' + key).filter(function (r) { return !r.hidden; });
    var done = false;
    function run() {
      if (done) return; done = true;
      try { fn(KV.scope(key)); } catch (e) { if (window.console) console.error('KalaVigyan ' + key, e); }
    }
    if (!rs.length) return;
    if (!('IntersectionObserver' in window)) { run(); return; }
    var o = new IntersectionObserver(function (es) {
      if (es.some(function (e) { return e.isIntersecting; })) { o.disconnect(); run(); }
    }, { rootMargin: '1400px 0px' });
    rs.forEach(function (r) { o.observe(r); });
  };

  var ICON_X = '<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M2 2 L12 12 M12 2 L2 12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>';
  var ICON_OK = '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M3 8.5 L6.5 12 L13 4.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>';
  function toast(title, desc, tone) {
    var zone = document.getElementById('toasts'); if (!zone) return;
    var el = document.createElement('div');
    el.className = 'toast ' + (tone || 'success');
    el.innerHTML = '<span class="t-ic">' + ICON_OK + '</span><span class="t-body"><span class="t-title">' + esc(title) + '</span>' + (desc ? '<span class="t-desc">' + esc(desc) + '</span>' : '') + '</span><button class="t-x" type="button" aria-label="Dismiss">' + ICON_X + '</button>';
    zone.appendChild(el);
    while (zone.children.length > 3) zone.removeChild(zone.firstChild);
    var gone = function () { if (el.parentNode) el.parentNode.removeChild(el); };
    el.querySelector('.t-x').addEventListener('click', gone);
    setTimeout(gone, 5000);
  }
  KV.toast = toast;

  function effTheme() {
    var t = root.getAttribute('data-theme');
    if (t === 'light' || t === 'dark') return t;
    return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  }
  function paintTools() {
    $$('[data-kv-tool="theme"]').forEach(function (b) { b.setAttribute('aria-pressed', effTheme() === 'dark' ? 'true' : 'false'); });
    [['contrast', 'data-high-contrast'], ['text', 'data-larger-text'], ['motion', 'data-reduced-motion']].forEach(function (t) {
      $$('[data-kv-tool="' + t[0] + '"]').forEach(function (b) { b.setAttribute('aria-pressed', root.getAttribute(t[1]) === 'true' ? 'true' : 'false'); });
    });
  }
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-kv-tool]');
    if (!b) return;
    var k = b.getAttribute('data-kv-tool');
    if (k === 'theme') {
      var next = effTheme() === 'dark' ? 'light' : 'dark';
      root.setAttribute('data-theme', next); store('kv-theme', next);
    } else {
      var map = { contrast: ['data-high-contrast', 'kv-contrast'], text: ['data-larger-text', 'kv-text'], motion: ['data-reduced-motion', 'kv-motion'] }[k];
      var on = root.getAttribute(map[0]) === 'true';
      if (on) root.removeAttribute(map[0]); else root.setAttribute(map[0], 'true');
      store(map[1], on ? '' : 'true');
    }
    paintTools();
    window.dispatchEvent(new Event('kv-prefs'));
  });
  paintTools();

  var CD = { s: {}, c: {} };
  try { CD = JSON.parse(document.getElementById('kv-cites').textContent); } catch (e) {}
  var STR = {
    en: { one: '1 source for this sentence', many: '{n} sources for this sentence', open: 'Open the source', foot: 'Quotes are verbatim.', close: 'Close', relw: 'Reliability ', rel: { A: 'A · peer-reviewed or official', B: 'B · reputable reference', C: 'C · general web', D: 'D · unknown' }, from: 'From the {x}' },
    hi: { one: 'इस वाक्य का 1 स्रोत', many: 'इस वाक्य के {n} स्रोत', open: 'स्रोत खोलें', foot: 'उद्धरण स्रोत की अपनी भाषा में, शब्दशः हैं।', close: 'बंद करें', relw: 'विश्वसनीयता ', rel: { A: 'A · समकक्ष-समीक्षित या आधिकारिक', B: 'B · प्रतिष्ठित संदर्भ', C: 'C · सामान्य वेब', D: 'D · अज्ञात' }, from: null },
    ur: { one: 'اس جملے کا 1 ماخذ', many: 'اس جملے کے {n} ماخذ', open: 'ماخذ کھولیں', foot: 'اقتباسات ماخذ کی اپنی زبان میں، لفظ بہ لفظ ہیں۔', close: 'بند کریں', relw: 'اعتباریت ', rel: { A: 'A · ہم مرتبہ جائزہ شدہ یا سرکاری', B: 'B · معتبر حوالہ', C: 'C · عام ویب', D: 'D · نامعلوم' }, from: null }
  };
  var pop = document.getElementById('kv-pop');
  var scrim = document.getElementById('kv-scrim');
  var home = pop.parentNode;
  var current = null;
  function langOf(el) { var l = el.closest('[data-ui-lang]'); return l ? l.getAttribute('data-ui-lang') : 'en'; }
  function buildPop(btn) {
    var lang = langOf(btn), S = STR[lang] || STR.en;
    var gs = (btn.getAttribute('data-g') || '').split(' ').filter(Boolean);
    gs.sort(function (a, b) { return (CD.s[a] ? CD.s[a][0] : 0) - (CD.s[b] ? CD.s[b][0] : 0); });
    var seen = {}; gs = gs.filter(function (g) { if (seen[g]) return false; seen[g] = 1; return true; });
    var qs = CD.c[btn.getAttribute('data-c')] || [];
    var h = '<div class="pop-head"><p id="kv-pop-t">' + (gs.length === 1 ? S.one : S.many.replace('{n}', gs.length)) + '</p><button class="pop-close" type="button" aria-label="' + S.close + '">' + ICON_X + '</button></div>';
    gs.forEach(function (g) {
      var s = CD.s[g]; if (!s) return;
      h += '<div class="pop-src"><div class="pop-src-h"><b>' + s[0] + '</b><strong lang="en" dir="ltr">' + esc(s[1]) + '</strong></div>';
      h += '<p class="pop-by" lang="en" dir="ltr">' + esc(s[3]) + (s[4] ? ', ' + s[4] : '') + '</p>';
      if (s[7] && S.from) h += '<p class="pop-scope">' + esc(S.from.replace('{x}', s[7])) + '</p>';
      var seenq = {};
      qs.forEach(function (q) {
        if (q[0] !== g || !q[2] || seenq[q[2]]) return; seenq[q[2]] = 1;
        h += '<p class="pop-q" lang="en" dir="ltr">“' + esc(q[2]) + '”</p>' + (q[1] ? '<p class="pop-loc" lang="en" dir="ltr">' + esc(q[1]) + '</p>' : '');
      });
      h += '<p class="pop-rel"><span class="rel ' + esc(s[5]) + '" aria-hidden="true"></span>' + S.relw + esc(S.rel[s[5]] || s[5]) + '</p>';
      if (s[6]) h += '<p class="pop-loc"><a href="' + esc(s[6]) + '" rel="noopener" target="_blank">' + S.open + '</a></p>';
      h += '</div>';
    });
    h += '<p class="pop-foot">' + S.foot + '</p>';
    return { html: h, lang: lang };
  }
  function place(btn) {
    var vw = document.documentElement.clientWidth;
    pop.classList.remove('sheet', 'docked', 'floating');
    pop.style.left = pop.style.top = pop.style.width = pop.style.position = '';
    if (vw < 640) {
      document.body.appendChild(pop);
      pop.classList.add('sheet'); pop.setAttribute('aria-modal', 'true'); scrim.hidden = false; return;
    }
    pop.setAttribute('aria-modal', 'false'); scrim.hidden = true;
    var spread = btn.closest('.spread');
    var margin = spread && spread.querySelector(':scope > .margin');
    var inMain = spread && btn.closest('.spread > .main, .spread > .wide');
    if (vw >= 1200 && margin && inMain && margin.offsetParent !== null && getComputedStyle(margin).display !== 'none') {
      margin.appendChild(pop);
      pop.classList.add('docked');
      var m = margin.getBoundingClientRect(), r = btn.getBoundingClientRect();
      pop.style.top = Math.max(0, r.top - m.top - 14) + 'px';
      return;
    }
    document.body.appendChild(pop);
    pop.classList.add('floating');
    var rr = btn.getBoundingClientRect();
    var width = Math.min(380, vw - 32);
    var left = Math.max(16, Math.min(rr.left - 24, vw - 16 - width)) + window.scrollX;
    pop.style.position = 'absolute'; pop.style.width = width + 'px';
    pop.style.left = left + 'px'; pop.style.top = (rr.bottom + window.scrollY + 10) + 'px';
  }
  function close(returnFocus) {
    if (!current) return;
    current.setAttribute('aria-expanded', 'false');
    var s = current.closest('.s'); if (s) s.classList.remove('is-lit');
    pop.hidden = true; pop.classList.remove('is-open'); scrim.hidden = true;
    var c = current; current = null;
    if (returnFocus) c.focus({ preventScroll: true });
  }
  function open(btn) {
    if (current === btn) { close(true); return; }
    close(false);
    current = btn;
    var b = buildPop(btn);
    pop.innerHTML = b.html;
    pop.setAttribute('lang', b.lang);
    if (b.lang === 'ur') pop.setAttribute('dir', 'rtl'); else pop.removeAttribute('dir');
    pop.hidden = false;
    place(btn);
    pop.classList.remove('is-open'); void pop.offsetWidth; pop.classList.add('is-open');
    btn.setAttribute('aria-expanded', 'true');
    if (!reduced()) { btn.classList.remove('press'); void btn.offsetWidth; btn.classList.add('press'); }
    var s = btn.closest('.s'); if (s) s.classList.add('is-lit');
    pop.querySelector('.pop-close').addEventListener('click', function () { close(true); });
    pop.focus({ preventScroll: true });
  }
  pop.setAttribute('tabindex', '-1');
  document.addEventListener('click', function (e) {
    var btn = e.target.closest('.kcite');
    if (btn && !btn.closest('[inert]')) { e.preventDefault(); open(btn); return; }
    if (current && !pop.contains(e.target)) close(false);
  });
  scrim.addEventListener('click', function () { close(true); closeMenu(); });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') { if (current) { close(true); return; } if (menuOpen()) { closeMenu(true); return; } }
    if (e.key === 'Tab' && current && pop.classList.contains('sheet')) {
      var f = pop.querySelectorAll('button, a[href]');
      if (!f.length) return;
      var first = f[0], last = f[f.length - 1];
      if (e.shiftKey && (document.activeElement === first || document.activeElement === pop)) { e.preventDefault(); last.focus(); }
      else if (!e.shiftKey && document.activeElement === last) { e.preventDefault(); first.focus(); }
    }
  });
  var rt = 0;
  window.addEventListener('resize', function () { clearTimeout(rt); rt = setTimeout(function () { if (current) place(current); }, 80); });

  var srcStatus = document.getElementById('kv-src-status');
  var lit = [], litI = -1;
  function clearLit() { $$('.is-src').forEach(function (x) { x.classList.remove('is-src'); }); lit = []; litI = -1; }
  $$('.kv-sources .src').forEach(function (b) {
    b.addEventListener('click', function () {
      var on = b.getAttribute('aria-pressed') === 'true';
      $$('.kv-sources .src').forEach(function (x) { x.setAttribute('aria-pressed', 'false'); });
      clearLit();
      if (on) { srcStatus.innerHTML = ''; return; }
      b.setAttribute('aria-pressed', 'true');
      var g = b.getAttribute('data-g'), n = b.querySelector('b').textContent;
      $$('.kcite').forEach(function (c) {
        if ((' ' + c.getAttribute('data-g') + ' ').indexOf(' ' + g + ' ') < 0) return;
        if (c.closest('.kv-sources') || c.closest('[hidden]')) return;
        var s = c.closest('.s') || c.parentNode;
        if (lit.indexOf(s) < 0) { s.classList.add('is-src'); lit.push(s); }
      });
      srcStatus.innerHTML = '<span>Source ' + esc(n) + ' lights ' + lit.length + ' sentence' + (lit.length === 1 ? '' : 's') + ' on this page.</span>' + (lit.length ? '<button class="kv-btn sm" type="button" data-src-next>Show the first</button>' : '');
    });
  });
  document.addEventListener('click', function (e) {
    var b = e.target.closest('[data-src-next]');
    if (!b || !lit.length) return;
    litI = (litI + 1) % lit.length;
    lit[litI].scrollIntoView({ behavior: reduced() ? 'auto' : 'smooth', block: 'center' });
    b.textContent = 'Show the next (' + (litI + 1) + ' of ' + lit.length + ')';
  });

  document.addEventListener('click', function (e) {
    var a = e.target.closest('[data-rp-step]');
    if (!a) return;
    var p = a.getAttribute('data-rp-step').split(':');
    var fig = document.getElementById(p[0]);
    if (!fig) return;
    var btn = fig.querySelectorAll('.rp-rail button')[+p[1] - 1];
    if (btn) setTimeout(function () { btn.click(); }, reduced() ? 0 : 350);
  });
  $$('[data-kv-save]').forEach(function (b) {
    b.addEventListener('click', function () {
      var on = b.getAttribute('aria-pressed') === 'true';
      b.setAttribute('aria-pressed', String(!on));
      b.textContent = on ? 'Save' : 'Saved';
      if (!on) toast('Saved', 'Find it under Saved.', 'success');
    });
  });
  function settle(t) {
    var n = 0, last = null;
    (function chk() {
      n++;
      var want = parseFloat(getComputedStyle(root).scrollPaddingTop) || 0;
      var top = t.getBoundingClientRect().top;
      if (last !== null && Math.abs(top - last) < 2 && Math.abs(top - want) > 24) t.scrollIntoView({ behavior: 'auto', block: 'start' });
      last = top;
      if (n < 12) setTimeout(chk, 250);
    })();
  }
  function selTab(which, focus) {
    $$('[data-kv-ct]').forEach(function (t) {
      var on = t.getAttribute('data-kv-ct') === which;
      t.setAttribute('aria-selected', on ? 'true' : 'false');
      t.tabIndex = on ? 0 : -1;
      var p = document.getElementById(t.getAttribute('aria-controls'));
      if (p) p.hidden = !on;
      if (on && focus) t.focus();
    });
  }
  $$('[data-kv-ct]').forEach(function (t, i, all) {
    t.addEventListener('click', function () { selTab(t.getAttribute('data-kv-ct')); });
    t.addEventListener('keydown', function (e) {
      if (e.key !== 'ArrowRight' && e.key !== 'ArrowLeft' && e.key !== 'Home' && e.key !== 'End') return;
      e.preventDefault();
      var k = e.key === 'Home' ? 0 : e.key === 'End' ? all.length - 1 : (i + (e.key === 'ArrowRight' ? 1 : -1) + all.length) % all.length;
      selTab(all[k].getAttribute('data-kv-ct'), true);
    });
  });
  $$('.kv-q-more').forEach(function (b) {
    b.addEventListener('click', function () {
      var p = document.getElementById(b.getAttribute('aria-controls'));
      var on = b.getAttribute('aria-expanded') === 'true';
      if (p) p.hidden = on;
      b.setAttribute('aria-expanded', on ? 'false' : 'true');
      b.textContent = on ? 'Show the full question' : 'Show less';
    });
  });
  $$('[data-kv-goto]').forEach(function (b) {
    b.addEventListener('click', function () {
      var t = document.getElementById(b.getAttribute('data-kv-goto'));
      if (!t) return;
      if (b.getAttribute('data-kv-tab')) selTab(b.getAttribute('data-kv-tab'));
      t.scrollIntoView({ behavior: reduced() ? 'auto' : 'smooth', block: 'start' });
      settle(t);
      var f = t.querySelector('button');
      if (f) setTimeout(function () { f.focus({ preventScroll: true }); }, reduced() ? 0 : 600);
    });
  });

  var made = document.querySelector('[data-kv-made]');
  if (made) {
    var mBtn = made.querySelector('[data-kv-made-play]');
    var mSrc = $$('.kv-ms', made), mSec = $$('.kv-mw', made), mPg = $$('.prog li', made);
    var mReady = made.querySelector('[data-kv-made-ready]'), mSay = made.querySelector('[data-kv-made-status]');
    var mT = [];
    var SRC0 = 500, SRC_STEP = Math.max(60, Math.round(4200 / Math.max(1, mSrc.length))), SEC0 = 1400, SEC_STEP = 820;
    var SRC_END = SRC0 + SRC_STEP * mSrc.length, SEC_END = SEC0 + SEC_STEP * mSec.length;
    var PG = [[0, 450], [450, SRC_END], [SEC0, SEC_END], [SEC0 + 300, SEC_END + 500], [SEC_END + 200, SEC_END + 1200]];
    var END = SEC_END + 1300;
    function mRender(t) {
      mSrc.forEach(function (li, i) { li.classList.toggle('is-in', t >= SRC0 + i * SRC_STEP); });
      mSec.forEach(function (li, i) {
        var a = SEC0 + i * SEC_STEP;
        li.classList.toggle('is-in', t >= a);
        li.classList.toggle('is-busy', t >= a && t < a + SEC_STEP - 120);
        li.classList.toggle('is-done', t >= a + SEC_STEP - 120);
      });
      var on = [];
      mPg.forEach(function (li, i) {
        var w = PG[i] || PG[PG.length - 1];
        var st = t >= w[1] ? 'done' : (t >= w[0] ? 'on' : 'next');
        li.classList.toggle('is-done', st === 'done');
        li.classList.toggle('is-on', st === 'on');
        if (st === 'on') { li.setAttribute('aria-current', 'step'); var l = li.querySelector('.pg-l'); if (l) on.push(l.textContent); } else li.removeAttribute('aria-current');
      });
      if (mReady) mReady.classList.toggle('is-in', t >= END);
      if (mSay) mSay.textContent = t >= END ? 'The answer is ready' : on.join(', ');
    }
    function mStop() { mT.forEach(clearTimeout); mT = []; }
    function mPlay() {
      mStop();
      if (reduced()) { made.classList.remove('is-run'); mRender(END); return; }
      made.classList.add('is-run');
      mRender(0);
      var start = performance.now();
      (function step() {
        var t = performance.now() - start;
        mRender(t);
        if (t < END) mT.push(setTimeout(step, 50)); else { made.classList.remove('is-run'); mBtn.textContent = 'Watch it again'; }
      })();
      mBtn.textContent = 'Watching';
    }
    mRender(END);
    if (mBtn) mBtn.addEventListener('click', mPlay);
  }

  var chapters = $$('section.kv-ch');
  var railLinks = $$('.kv-rail a');
  var menuBtn = document.getElementById('kv-menu-btn');
  var menu = document.getElementById('kv-menu');
  var menuLabel = document.getElementById('kv-menu-label');
  function setCurrent(id) {
    railLinks.forEach(function (a) {
      var on = a.getAttribute('href') === '#' + id;
      if (on) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current');
      if (on) {
        var ol = a.closest('ol');
        if (ol && ol.scrollWidth > ol.clientWidth) {
          var l = a.offsetLeft - ol.clientWidth / 2 + a.offsetWidth / 2;
          ol.scrollTo({ left: Math.max(0, l), behavior: reduced() ? 'auto' : 'smooth' });
        }
      }
    });
    $$('#kv-menu a').forEach(function (a) { if (a.getAttribute('href') === '#' + id) a.setAttribute('aria-current', 'location'); else a.removeAttribute('aria-current'); });
    var ch = document.getElementById(id);
    if (ch && menuLabel) {
      var n = +ch.getAttribute('data-ch');
      menuLabel.innerHTML = (n ? '<b>' + n + '</b>' : '') + '<span>' + esc(ch.getAttribute('data-label')) + '</span>';
    }
  }
  if ('IntersectionObserver' in window && chapters.length) {
    var vis = {};
    var so = new IntersectionObserver(function (es) {
      es.forEach(function (e) { vis[e.target.id] = e.isIntersecting; });
      for (var i = 0; i < chapters.length; i++) { if (vis[chapters[i].id]) { setCurrent(chapters[i].id); break; } }
    }, { rootMargin: '-35% 0px -60% 0px' });
    chapters.forEach(function (c) { so.observe(c); });
  }
  function menuOpen() { return menu && !menu.hidden; }
  function openMenu() { menu.hidden = false; scrim.hidden = false; menuBtn.setAttribute('aria-expanded', 'true'); var a = menu.querySelector('a[aria-current]') || menu.querySelector('a'); if (a) a.focus(); }
  function closeMenu(focus) { if (!menuOpen()) return; menu.hidden = true; if (!current) scrim.hidden = true; menuBtn.setAttribute('aria-expanded', 'false'); if (focus) menuBtn.focus(); }
  if (menuBtn) menuBtn.addEventListener('click', function () { if (menuOpen()) closeMenu(true); else openMenu(); });
  if (menu) {
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) closeMenu(false); });
    var mc = menu.querySelector('.kv-menu-close'); if (mc) mc.addEventListener('click', function () { closeMenu(true); });
  }

  var player = document.getElementById('kv-player');
  var LS = { sents: [], i: 0, playing: false, rate: 1, timer: 0, wi: 0, words: [], speech: false, utter: null, totalW: 0, startT: 0, base: 0 };
  function sentText(s) {
    var c = s.cloneNode(true);
    $$('.kcite', c).forEach(function (x) { x.remove(); });
    return c.textContent.replace(/\s+/g, ' ').trim();
  }
  function collect() {
    LS.sents = $$('#answer .ans-lede .s, .kv-ch:not(#answer) .t-lede .s').filter(function (s) {
      return !s.closest('[hidden], .kv-lang, .lang-demo, .kv-alt, #media, .kv-made-how, .kv-coda, details:not([open])');
    });
    LS.counts = LS.sents.map(function (s) { return sentText(s).split(' ').length; });
    LS.totalW = LS.counts.reduce(function (a, b) { return a + b; }, 0);
    LS.before = [];
    var acc = 0; LS.counts.forEach(function (c) { LS.before.push(acc); acc += c; });
  }
  collect();
  $$('[data-listen-min]').forEach(function (el) { el.textContent = Math.max(1, Math.round(LS.totalW / 150)); });
  function mmss(t) { t = Math.max(0, Math.round(t)); return Math.floor(t / 60) + ':' + ('0' + (t % 60)).slice(-2); }
  function sectionName(s) {
    var ch = s.closest('.kv-ch');
    if (!ch || ch.id === 'answer') return 'The short answer';
    var n = +ch.getAttribute('data-ch');
    return (n ? n + ' · ' : '') + ch.getAttribute('data-label');
  }
  function unwrap(s) { if (s && s.__orig != null) { s.innerHTML = s.__orig; s.__orig = null; } if (s) s.classList.remove('is-reading'); }
  function wrapWords(s) {
    s.__orig = s.innerHTML;
    var walker = document.createTreeWalker(s, NodeFilter.SHOW_TEXT, { acceptNode: function (n) { return n.parentNode.closest('.kcite') ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT; } });
    var nodes = []; while (walker.nextNode()) nodes.push(walker.currentNode);
    var words = [];
    nodes.forEach(function (n) {
      var parts = n.nodeValue.split(/(\s+)/);
      var frag = document.createDocumentFragment();
      parts.forEach(function (p) {
        if (!p) return;
        if (/^\s+$/.test(p)) { frag.appendChild(document.createTextNode(p)); return; }
        var sp = document.createElement('span'); sp.className = 'kv-w'; sp.textContent = p; frag.appendChild(sp); words.push(sp);
      });
      n.parentNode.replaceChild(frag, n);
    });
    return words;
  }
  function paint() {
    var s = LS.sents[LS.i];
    var el = player.querySelector('.kvp-where'), st = player.querySelector('.kvp-status');
    el.textContent = s ? sectionName(s) : '';
    st.textContent = 'Sentence ' + (LS.i + 1) + ' of ' + LS.sents.length;
    var done = (LS.before[LS.i] || 0) + LS.wi;
    var secs = done / (150 * LS.rate) * 60, tot = LS.totalW / (150 * LS.rate) * 60;
    player.querySelector('.kvp-t').textContent = mmss(secs) + ' / ' + mmss(tot);
    player.querySelector('.kvp-bar b').style.width = (LS.totalW ? done / LS.totalW * 100 : 0) + '%';
    var pb = player.querySelector('.kvp-play');
    pb.setAttribute('aria-label', LS.playing ? 'Pause' : 'Play');
    pb.innerHTML = LS.playing ? '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="3.5" y="2.8" width="3.2" height="10.4" rx=".8" fill="currentColor"/><rect x="9.3" y="2.8" width="3.2" height="10.4" rx=".8" fill="currentColor"/></svg>' : '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 2.8 L13 8 L4.5 13.2 Z" fill="currentColor"/></svg>';
  }
  function markWord() {
    LS.words.forEach(function (w, k) { w.classList.toggle('is-word', k === LS.wi); });
    paint();
  }
  function stopTimers() { clearTimeout(LS.timer); if (LS.speech && window.speechSynthesis) { try { speechSynthesis.cancel(); } catch (e) {} } }
  function useSpeech() {
    if (!('speechSynthesis' in window)) return false;
    var v = speechSynthesis.getVoices();
    return v && v.length > 0;
  }
  function voice() {
    var vs = speechSynthesis.getVoices();
    return vs.filter(function (v) { return /en[-_]IN/i.test(v.lang); })[0] || vs.filter(function (v) { return /^en/i.test(v.lang); })[0] || vs[0];
  }
  function startSentence(i, scroll) {
    stopTimers();
    unwrap(LS.sents[LS.i]);
    LS.i = Math.max(0, Math.min(LS.sents.length - 1, i));
    var s = LS.sents[LS.i];
    if (!s) return;
    s.classList.add('is-reading');
    LS.words = wrapWords(s);
    LS.wi = 0;
    if (scroll !== false) {
      var r = s.getBoundingClientRect();
      if (r.top < 90 || r.bottom > window.innerHeight - 120) s.scrollIntoView({ behavior: reduced() ? 'auto' : 'smooth', block: 'center' });
    }
    markWord();
    if (!LS.playing) return;
    if (LS.speech) {
      var text = LS.words.map(function (w) { return w.textContent; }).join(' ');
      var starts = []; var acc = 0; LS.words.forEach(function (w) { starts.push(acc); acc += w.textContent.length + 1; });
      var u = new SpeechSynthesisUtterance(text);
      u.rate = LS.rate; var vv = voice(); if (vv) { u.voice = vv; u.lang = vv.lang; }
      u.onboundary = function (e) {
        if (e.name && e.name !== 'word') return;
        var k = 0; for (var j = 0; j < starts.length; j++) { if (starts[j] <= e.charIndex) k = j; }
        LS.wi = k; markWord();
      };
      u.onend = function () { if (LS.utter !== u) return; next(true); };
      u.onerror = function () { if (LS.utter !== u) return; LS.speech = false; tick(); };
      LS.utter = u;
      speechSynthesis.speak(u);
    } else {
      tick();
    }
  }
  function tick() {
    clearTimeout(LS.timer);
    if (!LS.playing) return;
    var ms = 60000 / (150 * LS.rate);
    LS.timer = setTimeout(function () {
      if (LS.wi < LS.words.length - 1) { LS.wi++; markWord(); tick(); }
      else next(true);
    }, ms);
  }
  function next(auto) {
    if (LS.i >= LS.sents.length - 1) {
      LS.playing = false; stopTimers(); LS.wi = LS.words.length - 1; markWord();
      player.querySelector('.kvp-status').textContent = 'Read to the end';
      return;
    }
    startSentence(LS.i + 1);
  }
  function play() {
    LS.playing = true;
    LS.speech = useSpeech();
    startSentence(LS.i);
  }
  function pause() { LS.playing = false; stopTimers(); paint(); }
  function openPlayer() {
    player.hidden = false;
    document.body.classList.add('kv-has-player');
    if (!LS.sents.length) collect();
    if (!LS.playing) play();
    player.querySelector('.kvp-play').focus({ preventScroll: true });
  }
  if (player) {
    document.addEventListener('click', function (e) { if (e.target.closest('[data-listen-open]')) openPlayer(); });
    player.querySelector('.kvp-play').addEventListener('click', function () { if (LS.playing) pause(); else play(); });
    player.querySelector('.kvp-prev').addEventListener('click', function () { startSentence(LS.i - 1); });
    player.querySelector('.kvp-next').addEventListener('click', function () { startSentence(LS.i + 1); });
    player.querySelector('.kvp-rate').addEventListener('change', function (e) { LS.rate = +e.target.value; if (LS.playing) startSentence(LS.i, false); else paint(); });
    player.querySelector('.kvp-close').addEventListener('click', function () {
      LS.playing = false; stopTimers(); unwrap(LS.sents[LS.i]); player.hidden = true; document.body.classList.remove('kv-has-player');
    });
    player.addEventListener('keydown', function (e) {
      if (e.key === 'ArrowLeft') { e.preventDefault(); startSentence(LS.i - 1); }
      else if (e.key === 'ArrowRight') { e.preventDefault(); startSentence(LS.i + 1); }
      else if (e.key === 'Escape') { player.querySelector('.kvp-close').click(); }
    });
    if ('speechSynthesis' in window) { try { speechSynthesis.getVoices(); speechSynthesis.onvoiceschanged = function () {}; } catch (e) {} }
    LS.words = []; paint();
  }
})();
