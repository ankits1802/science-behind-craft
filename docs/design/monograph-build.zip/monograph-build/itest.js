const path = require('path');
const { chromium } = require('C:/dev/IIT/science-behind-craft/frontend/node_modules/playwright');
const file = 'file:///' + process.argv[2].split(path.sep).join('/');
const shotDir = process.argv[3];
(async () => {
  const browser = await chromium.launch();
  const results = [];
  function ok(name, v, extra) { results.push((v ? 'PASS ' : 'FAIL ') + name + (extra ? ' :: ' + extra : '')); }
  for (const width of [1440, 390]) {
    const ctx = await browser.newContext({ viewport: { width, height: width < 600 ? 844 : 900 } });
    const page = await ctx.newPage();
    const errs = [];
    page.on('pageerror', e => errs.push(e.message));
    page.on('console', m => { if (m.type() === 'error' && !/webrtc/.test(m.text())) errs.push(m.text()); });
    await page.goto(file, { waitUntil: 'load' });
    await page.waitForTimeout(600);
    const W = '[' + width + '] ';
    async function safeClick(sel, opts) { try { await page.click(sel, Object.assign({ timeout: 4000 }, opts || {})); } catch (e) { results.push('ERR click ' + sel + ' ' + e.message.slice(0, 140)); } }
    async function scrollTo(sel) { await page.evaluate(s => { const e = document.querySelector(s); if (e) e.scrollIntoView({ block: 'center' }); }, sel); await page.waitForTimeout(500); }

    await scrollTo('#answer .kcite');
    await safeClick('#answer .ans-lede .kcite');
    await page.waitForTimeout(300);
    const pop = await page.evaluate(() => { const p = document.getElementById('kv-pop'); return { hidden: p.hidden, cls: p.className, q: p.querySelectorAll('.pop-q').length, text: p.textContent.slice(0, 80) }; });
    ok(W + 'citation popover opens with quotes', !pop.hidden && pop.q > 0, JSON.stringify(pop));
    if (shotDir) await page.screenshot({ path: path.join(shotDir, 'itest-' + width + '-pop.png') });
    await page.keyboard.press('Escape');
    ok(W + 'popover closes on Escape', await page.evaluate(() => document.getElementById('kv-pop').hidden));

    await safeClick('button.q-more');
    ok(W + 'show full question', await page.evaluate(() => document.querySelector('button.q-more').getAttribute('aria-expanded') === 'true'));

    await scrollTo('figure.vat .vat-dip');
    await safeClick('figure.vat .vat-dip');
    await page.waitForTimeout(2900);
    ok(W + 'vat Dip again advances', await page.evaluate(() => document.querySelector('figure.vat').getAttribute('data-dips') === '2'));

    await scrollTo('#rp-blue');
    const b3 = await page.$$('#rp-blue .rp-rail button');
    try { await b3[2].click({ timeout: 4000 }); } catch (e) { results.push('ERR rp ' + e.message.slice(0, 140)); }
    await page.waitForTimeout(300);
    ok(W + 'reaction player step 3', await page.evaluate(() => document.getElementById('rp-blue').getAttribute('data-step') === '3'));
    await safeClick('#rp-blue .rp-play');
    await page.waitForTimeout(300);
    ok(W + 'reaction player plays', await page.evaluate(() => document.getElementById('rp-blue').classList.contains('is-playing')));
    await safeClick('#rp-blue .rp-play');

    await scrollTo('figure.mol .mol-turn');
    const before = await page.evaluate(() => document.querySelector('figure.mol .mol-dial').getAttribute('aria-valuenow'));
    await safeClick('figure.mol .mol-turn');
    await page.waitForTimeout(900);
    const after = await page.evaluate(() => document.querySelector('figure.mol .mol-dial').getAttribute('aria-valuenow'));
    ok(W + 'molecule turns', before !== after, before + ' -> ' + after);

    await scrollTo('iframe.kv-frame');
    await page.waitForTimeout(800);
    ok(W + 'explainer frame loads near', await page.evaluate(() => !!document.querySelector('iframe.kv-frame').getAttribute('srcdoc')));

    await scrollTo('[data-comp="cloth"] .lc-ribbon');
    const stageBtns = await page.$$('[data-comp="cloth"] [data-go]');
    if (stageBtns.length > 4) { try { await stageBtns[4].click({ timeout: 4000 }); } catch (e) { results.push('ERR stage click ' + e.message.slice(0, 140)); } await page.waitForTimeout(700); }
    ok(W + 'living cloth stage 5', await page.evaluate(() => { const b = document.querySelectorAll('[data-comp="cloth"] [data-go]')[4]; return b && b.getAttribute('aria-pressed') === 'true'; }), 'buttons ' + stageBtns.length);

    await scrollTo('[data-comp="region"]');
    await page.waitForTimeout(600);
    const lb = await page.$$('[data-comp="region"] [data-layer]');
    if (lb.length > 2) { try { await lb[2].click({ timeout: 4000 }); } catch (e) { results.push('ERR layer ' + e.message.slice(0, 140)); } await page.waitForTimeout(500); }
    ok(W + 'region map layer switch', await page.evaluate(() => { const b = document.querySelectorAll('[data-comp="region"] [data-layer]')[2]; return b && b.getAttribute('aria-pressed') === 'true'; }), 'layers ' + lb.length);

    await scrollTo('[data-comp="time"]');
    await page.waitForTimeout(600);
    const ev = await page.$$('[data-comp="time"] .ev-row [data-ev]');
    if (ev.length > 7) { try { await ev[7].click({ timeout: 4000 }); } catch (e) { results.push('ERR ev ' + e.message.slice(0, 140)); } await page.waitForTimeout(500); }
    ok(W + 'timeline select', await page.evaluate(() => { const b = document.querySelectorAll('[data-comp="time"] .ev-row [data-ev]')[7]; return b && b.getAttribute('aria-pressed') === 'true'; }), 'events ' + ev.length);

    await scrollTo('[data-comp="lab"]');
    await safeClick('[data-comp="lab"] [data-x="red"]');
    await page.waitForTimeout(200);
    ok(W + 'what-if red panel', await page.evaluate(() => !document.querySelector('[data-comp="lab"] [data-exp="red"]').hidden));
    await safeClick('[data-comp="lab"] [data-tapano]');
    ok(W + 'what-if tapano day', await page.evaluate(() => /Day 1/.test(document.querySelector('[data-comp="lab"] [data-tap-status]').textContent)));

    await scrollTo('#quiz');
    const opt = await page.$('#quiz .opt-b');
    if (opt) { try { await opt.click({ timeout: 4000 }); } catch (e) { results.push('ERR quiz ' + e.message.slice(0, 140)); } await page.waitForTimeout(300); }
    ok(W + 'quiz answers', await page.evaluate(() => !document.getElementById('quiz-next').disabled));

    await scrollTo('#kv-cite-answer');
    await safeClick('#kv-cite-answer .cb-seg button:nth-child(2)');
    ok(W + 'cite this answer BibTeX', await page.evaluate(() => /@misc|@online/.test(document.querySelector('#kv-cite-answer .cb-text').textContent)));

    await scrollTo('.lang-seg');
    await safeClick('.lang-seg button[data-lang="ur"]');
    ok(W + 'language Urdu', await page.evaluate(() => !document.querySelector('.lang-panel[data-lang-panel="ur"]').hidden));

    await scrollTo('.hero .vat-again');
    await safeClick('.hero .vat-again');
    await page.waitForTimeout(400);
    ok(W + 'specimen Play again', await page.evaluate(() => document.querySelector('.hero').getAttribute('data-phase') !== 'rest'), await page.evaluate(() => document.querySelector('.hero').getAttribute('data-phase')));

    await scrollTo('[id$="film-play"]');
    await safeClick('[id$="film-play"]');
    await page.waitForTimeout(600);
    ok(W + 'film plays', await page.evaluate(() => { const r = document.querySelector('[id$="film-range"]'); return r && +r.value > 0; }), await page.evaluate(() => document.querySelector('[id$="film-time"]').textContent));

    await scrollTo('#gen-reset');
    await safeClick('[id$="gen-reset"]');
    await page.waitForTimeout(1500);
    ok(W + 'media start over writes', await page.evaluate(() => /Writing section/.test(document.querySelector('[id$="gen-state"]').textContent)));

    await scrollTo('.kv-sources .src');
    await safeClick('.kv-sources .src');
    ok(W + 'source lights sentences', await page.evaluate(() => document.querySelectorAll('.is-src').length > 3), await page.evaluate(() => document.getElementById('kv-src-status').textContent));

    await safeClick('[data-listen-open]');
    await page.waitForTimeout(1200);
    ok(W + 'listen player opens', await page.evaluate(() => !document.getElementById('kv-player').hidden && document.querySelectorAll('.s.is-reading').length === 1), await page.evaluate(() => document.querySelector('.kvp-status').textContent));
    await safeClick('.kvp-next');
    await page.waitForTimeout(300);
    ok(W + 'listen next sentence', await page.evaluate(() => /Sentence 2/.test(document.querySelector('.kvp-status').textContent)));
    if (shotDir) await page.screenshot({ path: path.join(shotDir, 'itest-' + width + '-listen.png') });
    await safeClick('.kvp-close');

    await safeClick('[data-kv-tool="theme"]:not(.kv-menu *)', { force: true }).catch(() => {});
    ok(W + 'theme toggles', await page.evaluate(() => document.documentElement.getAttribute('data-theme') === 'dark'));
    await page.evaluate(() => { document.documentElement.removeAttribute('data-theme'); try { localStorage.removeItem('kv-theme'); } catch (e) {} });

    if (width < 600) {
      await safeClick('#kv-menu-btn');
      ok(W + 'chapter menu opens', await page.evaluate(() => !document.getElementById('kv-menu').hidden));
      if (shotDir) await page.screenshot({ path: path.join(shotDir, 'itest-390-menu.png') });
      await safeClick('#kv-menu a[href="#why-kachchh"]');
      await page.waitForTimeout(800);
      ok(W + 'chapter menu navigates', await page.evaluate(() => { const r = document.getElementById('why-kachchh').getBoundingClientRect(); return Math.abs(r.top) < 200; }));
    } else {
      await safeClick('.kv-rail a[href="#history"]');
      await page.waitForTimeout(900);
      ok(W + 'rail navigates and spies', await page.evaluate(() => document.querySelector('.kv-rail a[aria-current]').getAttribute('href')) === '#history', await page.evaluate(() => document.querySelector('.kv-rail a[aria-current]').getAttribute('href')));
    }
    ok(W + 'no page errors', errs.length === 0, errs.slice(0, 6).join(' | '));
    ok(W + 'no sideways scroll', await page.evaluate(() => document.documentElement.scrollWidth <= document.documentElement.clientWidth));
    await ctx.close();
  }
  console.log(results.join('\n'));
  await browser.close();
})();
