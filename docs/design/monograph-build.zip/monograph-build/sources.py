import re, json, html as H
from lib import *

KHAMIR = {
    'kc': 'https://exhibitions-khamir.org/ajrakh/khatris-community',
    'art': 'https://exhibitions-khamir.org/ajrakh/art-of-ajrakh',
    'adapt': 'https://exhibitions-khamir.org/ajrakh/adapting',
}


def norm_url(u):
    u = (u or '').strip()
    u = re.sub(r'^http://', 'https://', u)
    return u.rstrip('/')


class Registry:
    def __init__(self, S):
        self.S = S
        self.meta = {}
        self.by_url = {}
        self.local = {}
        self.claims = {}
        self.data = {}
        for k in ('chem', 'pt', 'mb', 'ask'):
            self.data[k] = jdata(S[k], 'cite-data')
        self.rm = jdata(S['rm'], 'kv-data')
        self.sa = jdata(S['sa'], 'kv-data')
        for k in ('chem', 'pt', 'mb', 'ask'):
            for sk, v in self.data[k]['sources'].items():
                self.local[(k, sk)] = dict(t=v.get('t'), by=v.get('by'), y=v.get('y'), r=v.get('r'), u=v.get('u'), sc=v.get('sc') or '', k=v.get('k'))
        for n, v in self.rm['sources'].items():
            d = dict(t=v.get('t'), by=v.get('by'), y=v.get('y'), r=v.get('r'), u=v.get('u'), sc='', k=v.get('kind'), full=v.get('full'))
            if n == '8':
                for code, url in KHAMIR.items():
                    self.local[('rm', '8:' + code)] = dict(d, u=url, t=None, full=None)
            else:
                self.local[('rm', n)] = d
        for sk, v in self.sa['sources'].items():
            self.local[('sa', sk)] = dict(t=v.get('t'), by=v.get('by'), y=v.get('y'), r=v.get('r'), u=v.get('url'), sc='', k=None)
        self.alltitles = {}
        for key, d in self.local.items():
            u = norm_url(d['u'])
            self.alltitles.setdefault(u, []).append(d)
        self.data['kv'] = {'sources': {}, 'claims': {}}

    def add_local(self, board, sk, d):
        d = dict(d)
        d.setdefault('sc', '')
        d.setdefault('k', None)
        self.local[(board, sk)] = d
        self.alltitles.setdefault(norm_url(d['u']), []).append(d)

    def alias(self, board, sk):
        key = board + '|' + sk
        if ('kv', key) not in self.local:
            self.local[('kv', key)] = self.local[(board, sk)]
        return key

    def kv_claim(self, cid, quotes):
        self.data['kv']['claims'][cid] = quotes

    def gkey(self, board, sk):
        d = self.local.get((board, sk))
        if d is None:
            raise KeyError((board, sk))
        u = norm_url(d['u'])
        if u not in self.by_url:
            g = 'g%d' % (len(self.by_url) + 1)
            self.by_url[u] = g
            self.meta[g] = self.merge(u)
        return self.by_url[u]

    def merge(self, u):
        ds = self.alltitles.get(u, [])
        ts = [d['t'] for d in ds if d.get('t')]
        fulls = [d['full'] for d in ds if d.get('full')]
        bys = [d['by'] for d in ds if d.get('by')]
        ys = [d['y'] for d in ds if d.get('y')]
        rs = [d['r'] for d in ds if d.get('r')]
        ks = [d['k'] for d in ds if d.get('k')]
        scs = [d['sc'] for d in ds if d.get('sc')]
        short = None
        if ts:
            clean = [re.sub(r'\s*\((?:Ajrakh exhibition)\)$', '', t) for t in ts]
            short = sorted(clean, key=len)[0]
        full = sorted(fulls + ts, key=len)[-1] if (fulls or ts) else short
        if u in KHAMIR.values():
            name = {KHAMIR['kc']: 'Khatris & Community', KHAMIR['art']: 'Art of Ajrakh', KHAMIR['adapt']: 'Adapting to the present'}[u]
            short = name
            full = name + ' (Ajrakh exhibition)'
            bys = ['Khamir']
            rs = ['C']
        by = sorted(bys, key=len)[-1] if bys else ''
        y = None
        for v in ys:
            try:
                y = int(v)
                break
            except Exception:
                pass
        return dict(t=short or full, full=full or short, by=by, y=y, r=(rs[0] if rs else 'C'), u=u, k=ks, sc=sorted(set(scs)))

    def add_claim(self, cid, quotes):
        if cid not in self.claims:
            self.claims[cid] = quotes


def rm_khamir_code(loc):
    loc = loc or ''
    if loc.startswith('Art of Ajrakh'):
        return 'art'
    if loc.startswith('Adapting'):
        return 'adapt'
    return 'kc'


CITE_RE = re.compile(r'<button class="cite"[^>]*>.*?</button>', re.S)


def convert_cites(R, board, frag):
    def one(m):
        tag = m.group(0)
        if ('data-claims="kv:' in tag) != (board == 'kv'):
            return tag
        st = tag[:tag.find('>') + 1]
        name, attrs = parse_attrs(st)
        A = dict(attrs)
        gkeys = []
        quotes = []
        if board in ('chem', 'pt', 'mb', 'ask', 'kv'):
            claims = (A.get('data-claims') or '').split()
            nmap = []
            for pair in (A.get('data-n') or '').split(','):
                if '=' in pair:
                    k, v = pair.split('=', 1)
                    nmap.append((k, int(v)))
            nmap.sort(key=lambda x: x[1])
            for k, _ in nmap:
                g = R.gkey(board, k)
                if g not in gkeys:
                    gkeys.append(g)
            for c in claims:
                for q in R.data[board]['claims'].get(c, []):
                    try:
                        g = R.gkey(board, q[0])
                    except KeyError:
                        continue
                    if g not in gkeys:
                        gkeys.append(g)
                    quotes.append([g, q[1] or '', q[2] or ''])
            cid = board + ':' + '+'.join(claims) if claims else board + ':n:' + A.get('data-n', '')
        elif board == 'rm':
            sid = A.get('data-sid')
            for it in R.rm['sents'].get(sid, []):
                n = str(it['n'])
                for q in it.get('qs', []):
                    sk = '8:' + rm_khamir_code(q.get('l')) if n == '8' else n
                    g = R.gkey('rm', sk)
                    if g not in gkeys:
                        gkeys.append(g)
                    quotes.append([g, q.get('l') or '', q.get('q') or ''])
                if not it.get('qs'):
                    sk = '8:kc' if n == '8' else n
                    g = R.gkey('rm', sk)
                    if g not in gkeys:
                        gkeys.append(g)
            cid = 'rm:' + sid
        elif board == 'sa':
            for pair in (A.get('data-n') or '').split(','):
                if '=' in pair:
                    k = pair.split('=', 1)[0]
                    g = R.gkey('sa', k)
                    if g not in gkeys:
                        gkeys.append(g)
            for qid in (A.get('data-q') or '').split(','):
                q = R.sa['quotes'].get(qid.strip())
                if q:
                    g = R.gkey('sa', q['s'])
                    if g not in gkeys:
                        gkeys.append(g)
                    quotes.append([g, q.get('loc') or '', q.get('q') or ''])
            cid = 'sa:' + (A.get('data-q') or '')
        R.add_claim(cid, quotes)
        return '<button class="kcite" type="button" data-c="%s" data-g="%s" aria-haspopup="dialog" aria-expanded="false">#</button>' % (H.escape(cid, quote=True), ' '.join(gkeys))
    return CITE_RE.sub(one, frag)


def group_of(meta):
    u = meta['u']
    host = re.sub(r'^https?://', '', u).split('/')[0]
    if 'pubchem' in host:
        return 'Compound records'
    if any(x in host for x in ('ipindia', 'origin-gi', 'ap.gov.in')):
        return 'Government records'
    if any(x in host for x in ('vam.ac.uk', 'metmuseum', 'artsandculture', 'imp-art.org', 'sahapedia', 'mingei')):
        return 'Museums and references'
    if any(x in host for x in ('niscpr', 'ntu.ac.uk', 'unl.edu', 'mmu.ac.uk', 'frontiersin', 'rhhz', 'culturalheritage')):
        return 'Scholarship'
    return 'Community and press'
