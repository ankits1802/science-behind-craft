import html
import re
import shutil
import sys
from pathlib import Path
from urllib.parse import urlencode

SOURCE = Path(sys.argv[1])
TARGET_DIR = Path(sys.argv[2])
SLUG = "Kutch-Ajrakh"
BASE = "/monographs/kutch-ajrakh/"

text = SOURCE.read_bytes().decode("utf-8").replace("\r\n", "\n")
assert "\r" not in text and "<!--" not in text

pictures = sorted(set(re.findall(r'src="img/([A-Za-z0-9._-]+)"', text)))
text, n = re.subn(r'src="img/', f'src="{BASE}img/', text)
assert n == 11, n
assert "img/" not in text.replace(f"{BASE}img/", "")


def ask_href(match: re.Match) -> str:
    question = html.unescape(match.group(1))
    query = urlencode({"q": question, "craft": SLUG})
    return f'<a href="/ask?{html.escape(query)}" data-ask="{match.group(1)}">'


text, n = re.subn(r'<a href="#reading" data-ask="([^"]*)">', ask_href, text)
assert n == 6, n

handler = re.compile(r"\n  \$\$\('\[data-ask\]'\)\.forEach\(function \(a\) \{\n.*?\n  \}\);", re.S)
text, n = handler.subn("", text)
assert n == 1, n
assert "[data-ask]" not in text

text, n = re.subn(r'<a class="kv-brand" href="#answer"', '<a class="kv-brand" href="/"', text)
assert n == 1, n

TARGET_DIR.mkdir(parents=True, exist_ok=True)
(TARGET_DIR / "img").mkdir(exist_ok=True)
(TARGET_DIR / "index.html").write_bytes(text.encode("utf-8"))
for name in pictures:
    shutil.copyfile(SOURCE.parent / "img" / name, TARGET_DIR / "img" / name)
print(len(pictures), "pictures", len(text.encode("utf-8")), "bytes")
