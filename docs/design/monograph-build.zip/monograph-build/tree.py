import sys,re; sys.path.insert(0,'_cons')
from tags import *
def txt(c,n=110):
    t=re.sub(r'<script.*?</script>|<style.*?</style>|<svg.*?</svg>','',c,flags=re.S)
    t=re.sub(r'<[^>]+>',' ',t); t=re.sub(r'\s+',' ',t).strip(); return t[:n]
def walk(el,depth,maxd,minsize):
    inn=inner(el)
    for a,b in children(inn):
        c=inn[a:b]
        if b-a<minsize: continue
        m=tag_re.match(c)
        head=re.sub(r'\s+',' ',m.group(0))[:120]
        print('  '*depth+f'[{b-a}] '+head+'  ~ '+txt(c))
        if depth<maxd and not c.startswith('<svg'): walk(c,depth+1,maxd,minsize)
f,pat,maxd,mins=sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4])
s=open(f,encoding='utf-8').read()
el,i=outer(s,pat)
print('ROOT',len(el),el[:150])
walk(el,0,maxd,mins)
