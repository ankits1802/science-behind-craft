import sys,re,html as H
sys.path.insert(0,'_cons')
from lib import *
out=rd(AB+'/ajrakh-complete.html')
def norm(t):
    t=H.unescape(t); t=re.sub(r'<[^>]+>',' ',t); t=re.sub(r'[\u2018\u2019\u201c\u201d"\']','',t)
    return re.sub(r'\s+',' ',t).strip().lower()
outn=norm(re.sub(r'<button class="kcite".*?</button>','',re.sub(r'<script.*?</script>|<style.*?</style>','',out,flags=re.S),flags=re.S))
def sents(h):
    h=re.sub(r'<button class="cite".*?</button>','',h,flags=re.S)
    res=[]
    for m in re.finditer(r'<span class="s"[^>]*>(.*?)</span></span>|<span class="s"[^>]*>([^<]*(?:<(?!/?span)[^>]*>[^<]*)*)</span>',h,re.S):
        t=norm(m.group(1) or m.group(2) or '')
        if len(t)>25: res.append(t)
    return res
def strip_phones(h):
    for pat in [r'<div class="pf-band"',r'<div class="phones"',r'<section class="phones"',r'<figure class="phone',r'<div class="side-phone"',r'<div class="board-',r'<section class="screen phones"',r'<div class="wrap bd-row"',r'<section class="screen build-note"']:
        while True:
            try: h=remove_el(h,pat)
            except Exception: break
            if not re.search(pat,h): break
    return h
boards={'ask':['id="answer"'],'chem':['id="answer"'],'pt':['<main'],'rm':['id="cite"','id="end"','id="listen"','id="gen"'],'mb':['id="craft"','id="answer"','class="hero"','class="four"','class="howcite"']}
tot=0;miss=0
for b,pats in boards.items():
    s=rd(PATHS[b])
    for p in pats:
        a,e=find_el(s,p); h=strip_phones(s[a:e])
        ss=sents(h)
        missing=[t for t in dict.fromkeys(ss) if t[:150] not in outn]
        tot+=len(set(ss)); miss+=len(missing)
        for t in missing: print(b,p,'MISSING:',t[:200])
print('total',tot,'missing',miss)
