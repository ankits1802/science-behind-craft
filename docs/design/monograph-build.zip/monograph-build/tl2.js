const path = require('path');
const { chromium } = require('C:/dev/IIT/science-behind-craft/frontend/node_modules/playwright');
(async () => {
  const b = await chromium.launch();
  for (const w of [390, 1440]) {
  const p = await (await b.newContext({ viewport: { width: w, height: 844 } })).newPage();
  const errs = []; p.on('pageerror', e => errs.push(e.message));
  await p.goto('file:///' + process.argv[2].split(path.sep).join('/'));
  await p.evaluate(() => document.querySelector('[data-comp="time"]').scrollIntoView());
  await p.waitForTimeout(1500);
  const r = await p.evaluate(() => {
    const tl = document.querySelector('[data-comp="time"]');
    const picks = tl.querySelectorAll('.tl-pick');
    const vis = Array.from(picks).map(x => x.getBoundingClientRect().width).join(',');
    picks[7].click();
    const on = Array.from(tl.querySelectorAll('.tl-li')).map(x => x.classList.contains('is-on') ? 1 : 0).join('');
    const card = Array.from(tl.querySelectorAll('[data-evc]')).filter(c => !c.hidden).map(c => c.getAttribute('data-evc')).join(',');
    return { n: picks.length, vis, on, card, axis: getComputedStyle(tl.querySelector('.tl-axis')).display, list: getComputedStyle(tl.querySelector('.tl-list')).display };
  });
  console.log(w, JSON.stringify(r), errs.join('|'));
  }
  await b.close();
})();
