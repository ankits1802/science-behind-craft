ID_RE_EARLY = re.compile(r'\sid="([^"]+)"')
DEF_TAGS = ('symbol', 'pattern', 'lineargradient', 'radialgradient', 'clippath', 'filter', 'mask', 'marker')
REF_RE = re.compile(r'(?:href|xlink:href)="#([^"]+)"|url\(#([^)\s]+)\)|url\(&quot;#([^&]+)&quot;\)')


def refs_in(h):
    return set(a or b or c for a, b, c in REF_RE.findall(h))


def find_def(src, i):
    try:
        a, b = find_el(src, r'\sid="%s"' % re.escape(i))
    except Exception:
        return None
    tag = re.match(r'<([a-zA-Z]+)', src[a:]).group(1).lower()
    if tag in DEF_TAGS:
        return src[a:b]
    d = src.rfind('<defs', 0, a)
    if d >= 0 and src.find('</defs>', d) > a:
        return src[a:b]
    return None


for b in sorted(set(f.board for ch in CHAPTERS for f in ch['items']) - {'raw'}):
    src = S[b]
    allh = ''.join(f.html for ch in CHAPTERS for f in ch['items'] if f.board == b)
    defined = set(ID_RE_EARLY.findall(allh))
    copies = []
    todo = sorted(refs_in(allh) - defined)
    done = set()
    while todo:
        i = todo.pop()
        if i in done or i in defined:
            continue
        done.add(i)
        el = find_def(src, i)
        if el is None:
            continue
        copies.append(el)
        defined |= set(ID_RE_EARLY.findall(el))
        todo.extend(sorted(refs_in(el) - defined))
    if copies:
        LOG.append('defs copied for %s: %d' % (b, len(copies)))
        CHAPTERS[-1]['items'].append(Frag(b, '<svg class="kv-defs" width="0" height="0" aria-hidden="true" focusable="false"><defs>' + ''.join(copies) + '</defs></svg>', []))


FIGLAB = re.compile(r'<p class="fig-no">Fig\. <b>(\d+)</b>')


def mark_figrefs(h, board):
    out = []
    pos = 0
    skip_next = False
    for m in re.finditer(r'<[^>]+>', h):
        text = h[pos:m.start()]
        if text and not skip_next:
            text = re.sub(r'\bFig\. (\d+)\b', lambda mm: '<span class="kv-figref" data-figref="%s:%s">Fig. %s</span>' % (board, mm.group(1), mm.group(1)), text)
        out.append(text)
        tag = m.group(0)
        out.append(tag)
        skip_next = 'data-figref=' in tag or tag.startswith('<script') or tag.startswith('<style') or 'class="fig-no"' in tag
        pos = m.end()
    out.append(h[pos:])
    return ''.join(out)


for ch in CHAPTERS:
    for f in ch['items']:
        if f.board == 'raw':
            continue
        f.html = FIGLAB.sub(lambda m: '<p class="fig-no" data-fig="%s:%s">Fig. <b>%s</b>' % (f.board, m.group(1), m.group(1)), f.html)
        f.html = mark_figrefs(f.html, f.figboard)

RESERVED = set([c['id'] for c in CHAPTERS] + ['kv-rail', 'kv-menu', 'kv-pop', 'kv-scrim', 'kv-player', 'kv-cites', 'kv-top', 'kv-main'])
STUB_IDS = ['theme-toggle', 'contrast-toggle', 'text-toggle', 'motion-toggle', 'pop', 'scrim']
SCRIPTED = ['chem', 'pt', 'mb', 'rm']

ID_RE = re.compile(r'\sid="([^"]+)"')
ids_by_board = {}
for ch in CHAPTERS:
    for f in ch['items']:
        if f.board == 'raw':
            continue
        for i in ID_RE.findall(f.html):
            ids_by_board.setdefault(f.board, {}).setdefault(i, 0)
            ids_by_board[f.board][i] += 1
for b in SCRIPTED:
    for i in STUB_IDS:
        ids_by_board.setdefault(b, {}).setdefault(i, 0)
        ids_by_board[b][i] += 1
owners = {}
for b, d in ids_by_board.items():
    for i in d:
        owners.setdefault(i, set()).add(b)
PREFIX = {}
for b, d in ids_by_board.items():
    PREFIX[b] = set(i for i in d if len(owners[i]) > 1 or i in RESERVED or d[i] > 1)
dups = {b: [i for i, n in d.items() if n > 1 and i not in STUB_IDS] for b, d in ids_by_board.items()}
LOG.append('dup ids within board: %s' % {b: v for b, v in dups.items() if v})

AIDS = {}


def prefix_ids(h, board):
    P = PREFIX.get(board, set())
    if not P:
        return h

    def fix_id(m):
        v = m.group(1)
        return ' id="%s-%s"' % (board, v) if v in P else m.group(0)
    h = ID_RE.sub(fix_id, h)

    def fix_ref_attr(m):
        name, val = m.group(1), m.group(2)
        toks = val.split()
        toks = [('%s-%s' % (board, t) if t in P else t) for t in toks]
        return '%s="%s"' % (name, ' '.join(toks))
    h = re.sub(r'\b(aria-labelledby|aria-describedby|aria-controls|aria-owns|aria-activedescendant|for|list|headers|data-copy|data-goto|data-orig)="([^"]*)"', fix_ref_attr, h)
    h = re.sub(r'(href|xlink:href)="#([^"]+)"', lambda m: '%s="#%s"' % (m.group(1), ('%s-%s' % (board, m.group(2)) if m.group(2) in P else m.group(2))), h)
    h = re.sub(r'url\(#([^)\s]+)\)', lambda m: 'url(#%s)' % (('%s-%s' % (board, m.group(1))) if m.group(1) in P else m.group(1)), h)
    h = re.sub(r'url\(&quot;#([^&]+)&quot;\)', lambda m: 'url(&quot;#%s&quot;)' % (('%s-%s' % (board, m.group(1))) if m.group(1) in P else m.group(1)), h)
    return h


def anc_open(board, t):
    if t.startswith('@@'):
        return '', ''
    name, attrs = parse_attrs(t)
    out = []
    for k, v in attrs:
        if k == 'id':
            AIDS.setdefault(board, set()).add(v)
            out.append(('data-aid', v))
        elif k in ('aria-labelledby', 'aria-label', 'aria-describedby', 'role', 'tabindex', 'hidden', 'aria-busy'):
            continue
        else:
            out.append((k, v))
    return build_tag(name, out), '</%s>' % name


def wrap(f):
    if f.board == 'raw':
        return f.html
    opens, closes = [], []
    for t in f.anc:
        o, c = anc_open(f.board, t)
        if o:
            opens.append(o)
            closes.insert(0, c)
    return '<div class="bx bx-%s">' % f.board + ''.join(opens) + prefix_ids(f.html, f.board) + ''.join(closes) + '</div>'


rail_items = ''.join('<li><a href="#%s"%s>%s<span>%s</span></a></li>' % (
    c['id'], ' aria-current="location"' if i == 0 else '', ('<b>%d</b>' % c['num']) if c['num'] else '', c['short']) for i, c in enumerate(CHAPTERS))
menu_items = ''.join('<li><a href="#%s">%s<span>%s</span></a></li>' % (c['id'], ('<b>%d</b>' % c['num']) if c['num'] else '<b></b>', c['label']) for c in CHAPTERS)

body_parts = []
for ch in CHAPTERS:
    body_parts.append('<section class="kv-ch" id="%s" data-ch="%d" data-label="%s" aria-label="%s">' % (ch['id'], ch['num'], H.escape(ch['label']), H.escape(ch['label'])))
    for f in ch['items']:
        body_parts.append(wrap(f))
    body_parts.append('</section>')
body = ''.join(body_parts)
body = re.sub(r'url\(#KVTILE-(\d+)\)', lambda m: 'url(#%s)' % (('pt-tile-' + m.group(1)) if ('id="pt-tile-%s"' % m.group(1)) in body else ('tile-' + m.group(1))), body)
body = body.replace('url(#KVWEAVE)', 'url(#pt-weave)' if 'id="pt-weave"' in body else 'url(#weave)')

order = []
seen = set()
for m in re.finditer(r'data-g="([^"]*)"', body):
    for g in m.group(1).split():
        if g not in seen:
            seen.add(g)
            order.append(g)
kin_a = body.find('<section class="kv-ch" id="kin"')
kin_b = body.find('<section class="kv-ch"', kin_a + 10)
outside = set()
for m in re.finditer(r'data-g="([^"]*)"', body[:kin_a] + body[kin_b:]):
    outside.update(m.group(1).split())
KIN_ONLY = [g for g in order if g not in outside]
MAIN = [g for g in order if g in outside]
order = MAIN + KIN_ONLY
NUM = {g: i + 1 for i, g in enumerate(order)}
for g in R.meta:
    if g not in NUM:
        LOG.append('uncited source registered: %s %s' % (g, R.meta[g]['t']))


def and_list(xs):
    xs = [str(x) for x in xs]
    if len(xs) == 1:
        return xs[0]
    return ', '.join(xs[:-1]) + ' and ' + xs[-1]


def fix_btn(m):
    tag = m.group(0)
    gs = re.search(r'data-g="([^"]*)"', tag).group(1).split()
    nums = sorted(set(NUM[g] for g in gs))
    gs_sorted = sorted(set(gs), key=lambda g: NUM[g])
    label = ('Source %d' % nums[0]) if len(nums) == 1 else ('Sources ' + and_list(nums))
    desc = '; '.join(R.meta[g]['t'] for g in gs_sorted)
    tag = tag.replace('aria-expanded="false">#</button>', 'aria-expanded="false" aria-label="%s" aria-description="%s">%s</button>' % (label, H.escape(desc, quote=True), ','.join(str(n) for n in nums)))
    return tag


body = re.sub(r'<button class="kcite"[^>]*>#</button>', fix_btn, body)


def gnum(m):
    u = norm_url(m.group(1))
    g = R.by_url.get(u)
    return str(NUM.get(g, '')) if g else ''


body = re.sub(r'<span data-gnum="([^"]+)"></span>', gnum, body)

FIGS = []
for m in re.finditer(r'data-fig="([^"]+)"', body):
    if m.group(1) not in FIGS:
        FIGS.append(m.group(1))
FIGMAP = {k: i + 1 for i, k in enumerate(FIGS)}
body = re.sub(r'<p class="fig-no" data-fig="([^"]+)">Fig\. <b>\d+</b>', lambda m: '<p class="fig-no" data-fig="%s">Fig. <b>%d</b>' % (m.group(1), FIGMAP[m.group(1)]), body)


def figref(m):
    k = m.group(1)
    if k not in FIGMAP:
        LOG.append('figref without figure: %s' % k)
        return m.group(0)
    return '<span class="kv-figref" data-figref="%s">Fig. %d</span>' % (k, FIGMAP[k])


body = re.sub(r'<span class="kv-figref" data-figref="([^"]+)">Fig\. \d+</span>', figref, body)


def short_t(g):
    d = R.meta[g]
    return d['t'] + (', %d' % d['y'] if d['y'] else '')


def margins(body):
    out = []
    pos = 0
    for m in re.finditer(r'<div class="spread', body):
        if m.start() < pos:
            continue
        a = m.start()
        b = element_end(body, a)
        seg = body[a:b]
        if 'class="margin note' in seg:
            gs = []
            for mm in re.finditer(r'data-g="([^"]*)"', seg):
                for g in mm.group(1).split():
                    if g not in gs:
                        gs.append(g)
            gs.sort(key=lambda g: NUM[g])
            ul = '<ul>' + ''.join('<li data-g="%s"><b>%d</b><span>%s</span></li>' % (g, NUM[g], H.escape(short_t(g))) for g in gs) + '</ul>'
            i = seg.find('class="margin note')
            j = seg.find('>', i) + 1
            k = seg.find('<ul', j)
            if k >= 0 and k - j < 5:
                ke = element_end(seg, k)
                seg = seg[:k] + ul + seg[ke:]
            else:
                seg = seg[:j] + ul + seg[j:]
            if not gs:
                seg = seg.replace(ul, '')
        out.append(body[pos:a])
        out.append(seg)
        pos = b
    out.append(body[pos:])
    return ''.join(out)


body = margins(body)

counts = {'A': 0, 'B': 0, 'C': 0, 'D': 0}
for g in MAIN:
    counts[R.meta[g]['r']] = counts.get(R.meta[g]['r'], 0) + 1
NS = len(MAIN)
NK = len(KIN_ONLY)
prov = ('<span class="kv-prov-n">Drawn from %d sources</span><span class="rel-strip" role="img" aria-label="Reliability of the %d sources: %d graded A, %d graded B, %d graded C">'
        '<span class="rs-g"><span class="rel A" aria-hidden="true"></span>A&#8239;%d</span><span class="rs-g"><span class="rel B" aria-hidden="true"></span>B&#8239;%d</span><span class="rs-g"><span class="rel C" aria-hidden="true"></span>C&#8239;%d</span></span>'
        '<a class="kv-prov-k" href="#kv-src-kin">%d more for the kin crafts</a>') % (NS, NS, counts['A'], counts['B'], counts['C'], counts['A'], counts['B'], counts['C'], NK)
body = body.replace('@@PROV@@', prov).replace('@@NSRC@@', str(NS)).replace('@@NA@@', str(counts['A'])).replace('@@NB@@', str(counts['B'])).replace('@@NC@@', str(counts['C'])).replace('@@NMAIN@@', str(NS))
SEC_FIG = {1: 'Drawing the molecules: alizarin, C<sub>14</sub>H<sub>8</sub>O<sub>4</sub> · PubChem CID 6293', 2: 'Setting out the dates, from Al Fustat to 2024', 3: 'Drawing the cloth after each of its eleven stages',
           4: 'Drawing the map in 8 steps, its river and its rain', 5: 'Setting out the GI dates and the yardage', 6: 'Finding a picture: the priest-king, Wikimedia Commons', 7: 'Drawing the stages of preparation'}
toc_titles = re.findall(r'<li><a href="#[^"]+"><b>(\d)</b><span>(.*?)</span></a></li>', body[:body.find('<section class="kv-ch" id="cloth"')])
made_src = ''.join('<li class="kv-ms" style="--i:%d"><b>%d</b><span class="kv-ms-t">%s</span><span class="relw"><span class="rel %s" aria-hidden="true"></span>%s</span></li>' % (k, NUM[g], H.escape(R.meta[g]['t']), R.meta[g]['r'], R.meta[g]['r']) for k, g in enumerate(MAIN))
made_sec = ''.join('<li class="kv-mw" style="--i:%d"><b>%s</b><span class="kv-mw-t">%s</span><span class="kv-mw-f"><span class="kv-ok">%s</span><span>%s</span></span></li>' % (k, n, t, CHECK, SEC_FIG.get(int(n), '')) for k, (n, t) in enumerate(toc_titles))
body = body.replace('@@MADESRC@@', made_src).replace('@@MADESEC@@', made_sec)

SUPPORT = {}
for m in re.finditer(r'<button class="kcite"[^>]*data-g="([^"]*)"', body):
    for g in set(m.group(1).split()):
        SUPPORT[g] = SUPPORT.get(g, 0) + 1
REL = {'A': 'A · peer-reviewed or official', 'B': 'B · reputable reference', 'C': 'C · general web', 'D': 'D · unknown'}
GROUPS = ['Government records', 'Scholarship', 'Museums and references', 'Community and press', 'Compound records']
grouped = {k: [] for k in GROUPS}
for g in MAIN:
    grouped[group_of(R.meta[g])].append(g)


def src_item(g):
    d = R.meta[g]
    by = H.escape(d['by']) + (', %d' % d['y'] if d['y'] else '')
    n = SUPPORT.get(g, 0)
    sc = ''
    scs = [x for x in d['sc'] if x and x != 'compound records']
    if scs:
        sc = '<span class="mg"><span>From the %s</span></span>' % H.escape(scs[0].replace('From the ', ''))
    return ('<li class="kv-src-li"><button type="button" class="src" data-g="%s" aria-pressed="false"><b>%d</b><span class="src-main"><span class="src-t">%s</span>'
            '<small><span>%s</span><span class="relw"><span class="rel %s" aria-hidden="true"></span>%s</span><span>Supports %d sentence%s here</span></small>%s</span></button>'
            '<a class="kv-src-link" href="%s" rel="noopener" target="_blank">Open the source<span class="vh">: %s</span></a></li>') % (
        g, NUM[g], H.escape(d['full']), by, d['r'], REL[d['r']], n, '' if n == 1 else 's', sc, H.escape(d['u'], quote=True), H.escape(d['t']))


src_html = '<div class="kv-src-status" role="status" id="kv-src-status"></div><div class="sources kv-sources">' + ''.join(
    '<div class="src-group"><h3>%s</h3><ul>%s</ul></div>' % (k, ''.join(src_item(g) for g in grouped[k])) for k in GROUPS if grouped[k]) + '</div>' + (
    '<div class="kv-src-kin" id="kv-src-kin"><h3 class="kv-sub-h">For the kin crafts</h3><p class="kv-sub-d">%d sources that support only the sentences of other monographs quoted in chapter 9. They are counted apart from the %d sources of this answer.</p><details class="kv-more kv-src-more"><summary><span class="kv-more-o">Show the %d sources</span><span class="kv-more-c">Hide them</span></summary><div class="sources kv-sources"><div class="src-group"><ul>%s</ul></div></div></details></div>' % (NK, NS, NK, ''.join(src_item(g) for g in KIN_ONLY)) if KIN_ONLY else '')
body = body.replace('@@SOURCES@@', src_html)

pics = []
seen_pics = set()
for m in re.finditer(r'<img [^>]*src="(img/[^"]+)"[^>]*>', body):
    src = m.group(1)
    if src in seen_pics:
        LOG.append('picture repeats: ' + src)
        continue
    seen_pics.add(src)
    tail = body[m.end():m.end() + 6000]
    cm = re.search(r'<p class="credit"[^>]*>(.*?)</p>|<p class="lc-credit">(.*?)</p>|<p class="op-credit">(.*?)</p>', tail, re.S)
    alt = re.search(r'alt="([^"]*)"', m.group(0))
    credit = (cm.group(1) or cm.group(2) or cm.group(3)) if cm else ''
    credit = re.sub(r'<span class="op-cap">.*?</span>', '', credit)
    pics.append((alt.group(1) if alt else src, credit.strip()))
pt_cred, _ = get('pt', r'<section class="wrap credits"')
PT_DESC = {}
for mm in re.finditer(r'<li>([^<]*?):\s*<a href="([^"]+)"', pt_cred):
    PT_DESC[mm.group(2)] = H.unescape(mm.group(1)).rstrip('.')
def pdesc(a, c):
    if 'cropped' in c:
        return a
    u = re.search(r'href="([^"]+)"', c)
    return PT_DESC.get(u.group(1), a) if u else a
data_ul = re.search(r'<h2 class="cr-sub">Data</h2>(.*?)$', pt_cred, re.S).group(1)
data_ul = re.sub(r'</section>\s*$', '', data_ul)
cids_used = sorted(set(int(x) for x in re.findall(r'pubchem\.ncbi\.nlm\.nih\.gov/compound/(\d+)', body)) | set(int(x) for x in re.findall(r'data-cid="(\d+)"', body)))
data_ul = re.sub(r'checked 18 Nov 2026 \(CIDs [^)]*\)', 'checked 18 Nov 2026 (CIDs ' + ', '.join(str(x) for x in cids_used) + '), and on 19 Nov 2026 for the iron, dithionite, sulfite, sodium hydroxide and Tyrian purple records', data_ul)
extra_data = '<li>Temperature: GHCN-CAMS 2 m air temperature, annual means for Kachchh district, NOAA Climate Prediction Center, 1981 to 2025.</li>'
data_ul = data_ul.replace('</ul>', '<li>Indigo: PubChem’s main record is CID 10215; the 3D model and the formula cards use CID 5318432, the same molecule in its (2E), C=O form.</li></ul>', 1)
credits = ('<section class="wrap credits kv-credits"><h3 class="cr-sub">Pictures</h3><ul class="cr-list">' + ''.join('<li>%s: %s</li>' % (H.escape(pdesc(a, c)), c) for a, c in pics) + '</ul>'
           '<h3 class="cr-sub">Data</h3>' + data_ul + '</section>')
body = body.replace('@@CREDITS@@', credits)

exec(open(CONS + '/build3.py', encoding='utf-8').read())
