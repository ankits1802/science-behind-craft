import sys,glob,os
from PIL import Image
d,pat,cols,rows,scale,out=sys.argv[1],sys.argv[2],int(sys.argv[3]),int(sys.argv[4]),float(sys.argv[5]),sys.argv[6]
fs=sorted(glob.glob(os.path.join(d,pat)))
os.makedirs(out,exist_ok=True)
per=cols*rows
for k in range(0,len(fs),per):
    ims=[Image.open(f).convert('RGB') for f in fs[k:k+per]]
    w=int(ims[0].width*scale); h=int(ims[0].height*scale)
    sheet=Image.new('RGB',(cols*(w+6),rows*(h+6)),(255,0,255))
    for i,im in enumerate(ims):
        sheet.paste(im.resize((w,h)),((i%cols)*(w+6),(i//cols)*(h+6)))
    sheet.save(os.path.join(out,'grid-%s-%02d.jpg'%(pat.replace('*','').replace('.png',''),k//per)),quality=75)
print(len(fs), (len(fs)+per-1)//per)
