import sys,glob,os
from PIL import Image
d,pat,per,scale,out=sys.argv[1],sys.argv[2],int(sys.argv[3]),float(sys.argv[4]),sys.argv[5]
fs=sorted(glob.glob(os.path.join(d,pat)))
os.makedirs(out,exist_ok=True)
for k in range(0,len(fs),per):
    ims=[Image.open(f).convert('RGB') for f in fs[k:k+per]]
    w=int(ims[0].width*scale); hs=[int(i.height*scale) for i in ims]
    sheet=Image.new('RGB',(w,sum(hs)+4*len(ims)),(255,0,255))
    y=0
    for im,h in zip(ims,hs):
        sheet.paste(im.resize((w,h)),(0,y)); y+=h+4
    sheet.save(os.path.join(out,'sheet-%s-%02d.jpg'%(pat.replace('*','').replace('.png',''),k//per)),quality=72)
print(len(fs))
