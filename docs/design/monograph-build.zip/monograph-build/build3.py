import cssproc

tokens_css = rd(SP + '/system/tokens.css')
TOKP = cssproc.tokens_decls(tokens_css)

universe = set()
for m in re.finditer(r'class="([^"]*)"', body):
    universe.update(m.group(1).split())
for m in re.finditer(r"class='([^']*)'", body):
    universe.update(m.group(1).split())
for m in re.finditer(r'class=([A-Za-z][\w-]*)', body):
    universe.add(m.group(1))


def board_js(b):
    s = S[b]
    return ''.join(m.group(2) for m in re.finditer(r'<script([^>]*)>(.*?)</script>', s, re.S) if 'json' not in m.group(1))


JS_WORDS = {}
for b in SCRIPTED:
    js = board_js(b)
    JS_WORDS[b] = set(re.findall(r'[A-Za-z_][\w-]*', js))
    for m in re.finditer(r"['\"]([a-z][\w]*-)['\"]\s*\+", js):
        JS_WORDS[b].add('PREFIX:' + m.group(1))


def board_universe(b):
    u = set(universe)
    u |= JS_WORDS.get(b, set())
    u |= set(['is-open', 'is-lit', 'is-src', 'press', 'sheet', 'docked', 'floating', 'is-playing', 'no-tr', 'run', 'off', 'dim', 'on', 'tight', 'is-reading', 'is-word', 'toast-zone', 'toast', 't-ic', 't-body', 't-title', 't-desc', 't-x', 'success', 'info', 'warning', 'error', 'is-done', 'is-on', 'is-asked'])
    return u


class U:
    def __init__(self, u, prefixes):
        self.u = u
        self.p = prefixes

    def __contains__(self, c):
        if c in self.u:
            return True
        return any(c.startswith(p) for p in self.p)


css_parts = []
glob_extra = []
elem_ids = {}
for m in re.finditer(r'<div class="bx bx-(\w+)">', body):
    pass
for b in ['chem', 'pt', 'rm', 'mb', 'ask', 'sa']:
    s = S[b]
    head = s[:s.find('<body')]
    css = ''.join(m.group(1) for m in re.finditer(r'<style[^>]*>(.*?)</style>', head, re.S))
    prefixes = [w[7:] for w in JS_WORDS.get(b, set()) if w.startswith('PREFIX:')]
    idfix = {'prefixed': PREFIX.get(b, set()), 'elements': set(ids_by_board.get(b, {}).keys())}
    sc = cssproc.Scoper(b, idfix, AIDS.get(b, set()), U(board_universe(b), prefixes), TOKP)
    out = sc.run(css)
    glob_extra.extend(sc.globals)
    css_parts.append('/* %s */\n' % b + out if False else out)
    LOG.append('css %s: kept %d dropped %d size %d' % (b, sc.kept, sc.dropped, len(out)))

pop_css = cssproc.global_pop_css(''.join(m.group(1) for m in re.finditer(r'<style[^>]*>(.*?)</style>', S['chem'][:S['chem'].find('<body')], re.S)))
rel_css = '.rel { width: 9px; height: 9px; border-radius: 50%; border: 1.5px solid var(--ink-2); display: inline-block; flex: none; } .rel.A { background: var(--ink-2); } .rel.B { background: linear-gradient(90deg, var(--ink-2) 50%, transparent 50%); }'
seen_g = []
for g in glob_extra:
    if g not in seen_g:
        seen_g.append(g)


def scope_inline_styles(body):
    out = []
    pos = 0
    for m in re.finditer(r'<style>(.*?)</style>', body, re.S):
        a = m.start()
        k = body.rfind('<div class="bx bx-', 0, a)
        b = re.match(r'<div class="bx bx-(\w+)">', body[k:]).group(1)
        idfix = {'prefixed': PREFIX.get(b, set()), 'elements': set(ids_by_board.get(b, {}).keys())}
        sc = cssproc.Scoper(b, idfix, AIDS.get(b, set()), None, TOKP)
        out.append(body[pos:a])
        out.append('<style>' + sc.run(m.group(1)) + '</style>')
        pos = m.end()
    out.append(body[pos:])
    return ''.join(out)


body = scope_inline_styles(body)
kv_css = rd(CONS + '/kv.css') + chr(10) + rd(CONS + '/kv2.css')
ALL_CSS = tokens_css + '\n' + '\n'.join(seen_g) + '\n' + pop_css + '\n' + rel_css + '\n' + '\n'.join(css_parts) + '\n' + kv_css

cites_json = {
    's': {g: [NUM[g], R.meta[g]['t'], R.meta[g]['full'], R.meta[g]['by'], R.meta[g]['y'], R.meta[g]['r'], R.meta[g]['u'],
              ([x for x in R.meta[g]['sc'] if x and x != 'compound records'] or [''])[0].replace('From the ', '')] for g in order},
    'c': {}
}
used_c = set(re.findall(r'data-c="([^"]+)"', body))
for cid in used_c:
    c2 = H.unescape(cid)
    cites_json['c'][cid] = R.claims.get(c2, [])
    if c2 != cid:
        cites_json['c'][c2] = R.claims.get(c2, [])

rmdata = R.rm
for q in rmdata.get('quiz', []):
    q['cite'] = convert_cites(R, 'rm', q.get('cite', ''))
    for o in q.get('opts', []):
        o['html'] = convert_cites(R, 'rm', o.get('html', ''))
film = jdata(S['rm'], 'film-subs') or {'subs': [], 'labels': []}
film['subs'] = [convert_cites(R, 'rm', x) for x in film['subs']]


def fill_nums_in(h):
    return re.sub(r'<button class="kcite"[^>]*>#</button>', fix_btn, h)


for q in rmdata.get('quiz', []):
    q['cite'] = fill_nums_in(q['cite'])
    for o in q.get('opts', []):
        o['html'] = fill_nums_in(o['html'])
film['subs'] = [fill_nums_in(x) for x in film['subs']]
for x in film['subs'] + [q['cite'] for q in rmdata.get('quiz', [])] + [o['html'] for q in rmdata.get('quiz', []) for o in q.get('opts', [])]:
    for cid in re.findall(r'data-c="([^"]+)"', x):
        c2 = H.unescape(cid)
        cites_json['c'][cid] = R.claims.get(c2, [])


SPLITS = {'myroba lan': 'myrobalan', 'co ntains': 'contains', 'fa bric': 'fabric', 'mo rdants': 'mordants', 'v illage': 'village', 'k esari': 'kesari'}


def fix_q(q, loc):
    for a, b in SPLITS.items():
        q = q.replace(a, b)
    if 'Na2S2O2' in q:
        q = q.replace('Na2S2O2 [sic]', 'Na2S2O2').replace('Na2S2O2', 'Na2S2O2 [sic]')
        loc = re.sub(r'\. The source prints.*$', '', loc or '')
        loc = (loc + '; ' if loc else '') + '[sic]: sodium dithionite is Na2S2O4'
    return q, loc


for cid in list(cites_json['c'].keys()):
    out = []
    for g, l, q in cites_json['c'][cid]:
        q2, l2 = fix_q(q, l)
        out.append([g, l2, q2])
    cites_json['c'][cid] = out


def jscript(id_, obj):
    return '<script type="application/json" id="%s">%s</script>' % (id_, json.dumps(obj, ensure_ascii=False).replace('</', '<\\/'))


stubs = ''
for b in SCRIPTED:
    st = ''.join('<button type="button" id="%s"></button>' % ((b + '-' + i) if i in PREFIX.get(b, set()) else i) for i in STUB_IDS)
    data = ''
    if b == 'chem':
        data = jscript('mol-data', jdata(S['chem'], 'mol-data'))
    if b == 'pt':
        data = jscript('rs-data', jdata(S['pt'], 'rs-data'))
    if b == 'rm':
        data = jscript('kv-data', rmdata) + jscript('film-subs', film)
    stubs += '<div class="bx bx-%s" hidden>%s%s</div>' % (b, st, data)


def patch(b, js):
    if b == 'chem':
        js = must(js, "var frameBase = frames.map(function (f) { return f.getAttribute('srcdoc') || ''; });",
                  "var frameBase = frames.map(function (f) { return f.getAttribute('data-srcdoc') || ''; }); frames.forEach(function (f) { KV.near(f, function () { f.__near = 1; rekey(); }, 700); }); window.addEventListener('kv-prefs', function () { rekey(); });")
        js = must(js, "frames.forEach(function (f, i) { f.setAttribute('srcdoc',", "frames.forEach(function (f, i) { if (!f.__near) return; f.setAttribute('srcdoc',")
        js = must(js, "arr(document.querySelectorAll('.mol[data-cid]')).forEach(function (f) { if (!f.closest('[inert]')) Viewer(f); });",
                  "arr(document.querySelectorAll('.mol[data-cid]')).forEach(function (f) { if (!f.closest('[inert]')) KV.near(f, function () { Viewer(f); }, 600); });")
    if b == 'rm':
        js = must(js, "var SCENE = 8000, ready = 6,", "var SCENE = 8000, ready = 7,")
        js = must(js, "a.addEventListener('click', function (e) { e.preventDefault(); toast('New question', a.getAttribute('data-ask'), 'info'); });",
                  "a.addEventListener('click', function (e) { e.preventDefault(); if (a.getAttribute('aria-disabled') === 'true') return; a.setAttribute('aria-disabled', 'true'); a.classList.add('is-asked'); var g = a.querySelector('.ago span'); if (g) g.textContent = 'Asked'; toast('Question asked', a.getAttribute('data-ask') + ' It opens as a new answer at Expert depth, in Recent.', 'success'); });")
    if b == 'pt':
        js = js.replace("all('[data-comp=\"region\"]').forEach(function (rs) {", "all('[data-comp=\"region\"]').forEach(function (rs) { KV.near(rs, function () {", 1)
        js = close_block(js, "KV.near(rs, function () {")
        js = js.replace("all('[data-comp=\"time\"]').forEach(function (tl) {", "all('[data-comp=\"time\"]').forEach(function (tl) { KV.near(tl, function () {", 1)
        js = close_block(js, "KV.near(tl, function () {")
    return js


def close_block(js, marker):
    i = js.find(marker)
    if i < 0:
        LOG.append('patch marker missing: ' + marker)
        return js
    start = js.rfind('{', 0, i)
    depth = 0
    j = start
    n = len(js)
    q = None
    while j < n:
        c = js[j]
        if q:
            if c == '\\':
                j += 2
                continue
            if c == q:
                q = None
        elif c in '\'"`':
            q = c
        elif c == '/' and js[j + 1] == '/':
            j = js.find('\n', j)
            continue
        elif c == '{':
            depth += 1
        elif c == '}':
            depth -= 1
            if depth == 0:
                return js[:j] + '}, 700); ' + js[j:]
        j += 1
    LOG.append('patch unbalanced: ' + marker)
    return js


board_scripts = ''
for b in SCRIPTED:
    js = board_js(b)
    m = re.search(r'\(function \(\) \{', js)
    main_js = js[m.start():] if m else js
    main_js = patch(b, main_js)
    board_scripts += "KV.boot('%s', function (document) {\n%s\n});\n" % (b, main_js)

restore = rd(CONS + '/js/chem_0.js')
kv_js = rd(CONS + '/kv.js')

MARK = '<svg class="mark" viewBox="0 0 32 32" aria-hidden="true"><path fill="currentColor" fill-rule="evenodd" d="M16.00 0.40 L19.34 7.93 L27.03 4.97 L24.07 12.66 L31.60 16.00 L24.07 19.34 L27.03 27.03 L19.34 24.07 L16.00 31.60 L12.66 24.07 L4.97 27.03 L7.93 19.34 L0.40 16.00 L7.93 12.66 L4.97 4.97 L12.66 7.93 Z M16.00 12.10 L19.38 14.05 L19.38 17.95 L16.00 19.90 L12.62 17.95 L12.62 14.05 Z"/></svg>'
TOOL_ICONS = {
    'theme': '<svg viewBox="0 0 16 16" aria-hidden="true"><circle cx="8" cy="8" r="6" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M8 2 A6 6 0 0 1 8 14 Z" fill="currentColor"/></svg>',
    'contrast': '<svg viewBox="0 0 16 16" aria-hidden="true"><rect x="2" y="2" width="12" height="12" rx="1.5" fill="none" stroke="currentColor" stroke-width="1.4"/><path d="M2 14 L14 2 V14 Z" fill="currentColor"/></svg>',
    'text': '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M1.5 13 L5 3.5 L8.5 13 M2.8 10 H7.2" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/><path d="M10 13 L12.5 7 L15 13 M10.9 11 H14.1" fill="none" stroke="currentColor" stroke-width="1.3" stroke-linecap="round" stroke-linejoin="round"/></svg>',
    'motion': '<svg viewBox="0 0 16 16" aria-hidden="true"><path d="M2 8 H12 M8.5 4.5 L12 8 L8.5 11.5" fill="none" stroke="currentColor" stroke-width="1.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
}
TOOL_NAMES = [('theme', 'Dark'), ('contrast', 'High contrast'), ('text', 'Larger text'), ('motion', 'Reduce motion')]
tools = ''.join('<button class="kv-tool" type="button" data-kv-tool="%s" aria-pressed="false">%s<span>%s</span></button>' % (k, TOOL_ICONS[k], n) for k, n in TOOL_NAMES)
tools_aria = ''.join('<button class="kv-tool" type="button" data-kv-tool="%s" aria-pressed="false" aria-label="%s">%s<span>%s</span></button>' % (k, n, TOOL_ICONS[k], n) for k, n in TOOL_NAMES)
X14 = '<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M2 2 L12 12 M12 2 L2 12" stroke="currentColor" stroke-width="1.6" stroke-linecap="round"/></svg>'

fonts = []
for b in ['chem', 'rm', 'mb', 'sa', 'ask', 'pt']:
    for m in re.finditer(r'<link rel="stylesheet" href="(https://fonts\.googleapis\.com/[^"]+)">', S[b]):
        u = m.group(1)
        if u not in fonts:
            fonts.append(u)
font_links = '<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>' + ''.join('<link rel="stylesheet" href="%s">' % u for u in fonts)

appbar = ('<header class="kv-appbar"><div class="kv-wrap"><a class="kv-brand" href="#answer" aria-label="KalaVigyan, कलाविज्ञान">' + MARK +
          '<span class="wm"><span class="wm-lat">KalaVigyan</span><span class="wm-rule"></span><span class="wm-deva" lang="hi">कलाविज्ञान</span></span></a>'
          '<p class="kv-crumb">Kutch Ajrakh · Expert answer and monograph</p>'
          '<div class="kv-tools" role="group" aria-label="Display">' + tools_aria + '</div></div></header>')
rail = '<nav class="kv-rail" aria-label="Chapters"><div class="kv-wrap"><ol>' + rail_items + '</ol></div></nav>'
menubar = ('<div class="kv-menubar"><div class="kv-wrap"><p id="kv-menu-label"><span>The answer</span></p>'
           '<button class="kv-menu-btn" id="kv-menu-btn" type="button" aria-expanded="false" aria-controls="kv-menu"><span>Chapters</span><svg viewBox="0 0 14 14" aria-hidden="true"><path d="M3 5 L7 9 L11 5" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round"/></svg></button></div></div>'
           '<div class="kv-menu" id="kv-menu" role="dialog" aria-modal="true" aria-label="Chapters" hidden><div class="kv-menu-h"><p>Chapters</p><button class="kv-menu-close" type="button" aria-label="Close">' + X14 + '</button></div>'
           '<ol>' + menu_items + '</ol><div class="kv-menu-tools" role="group" aria-label="Display">' + tools + '</div></div>')
player = ('<div class="kv-player" id="kv-player" role="region" aria-label="Listen to this answer" hidden><div class="kv-wrap">'
          '<div class="kvp-ctl"><button class="kvp-prev" type="button" aria-label="Previous sentence"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M12 3 L6 8 L12 13 Z M4 3 V13" fill="currentColor" stroke="currentColor" stroke-width="1.2"/></svg></button>'
          '<button class="kvp-play" type="button" aria-label="Play"></button>'
          '<button class="kvp-next" type="button" aria-label="Next sentence"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4 3 L10 8 L4 13 Z M12 3 V13" fill="currentColor" stroke="currentColor" stroke-width="1.2"/></svg></button></div>'
          '<div class="kvp-mid"><div class="kvp-top"><span class="kvp-where"></span><span class="kvp-status" role="status"></span></div><div class="kvp-bar" aria-hidden="true"><b></b></div><span class="kvp-t"></span></div>'
          '<div class="kvp-end"><select class="kvp-rate" aria-label="Reading speed"><option value="1">1×</option><option value="1.25">1.25×</option><option value="1.5">1.5×</option></select>'
          '<button class="kvp-close" type="button" aria-label="Close the player">' + X14 + '</button></div></div></div>')
foot = '<footer class="kv-foot"><div class="kv-wrap"><p>KalaVigyan, from IIT Kharagpur and its Centre of Excellence for Unified AI-Enabled Craft Ecosystem Platform. Every sentence opens to its source’s own words.</p></div></footer>'

doc = ('<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">'
       '<title>KalaVigyan · Kutch Ajrakh</title><meta name="description" content="Kutch Ajrakh, told in full: the Expert answer and the monograph on one page, every sentence cited.">'
       '<script>' + restore + '</script>' + font_links +
       '<style>' + ALL_CSS + '</style></head><body>'
       '<a class="kv-skip" href="#answer">Skip to the answer</a>' + appbar + rail + menubar +
       '<main id="kv-main">' + body + '</main>' + foot +
       '<div class="pop" id="kv-pop" role="dialog" aria-labelledby="kv-pop-t" hidden></div><div class="kv-scrim" id="kv-scrim" hidden></div>'
       '<div class="bx bx-rm"><div class="toast-zone" id="toasts" aria-live="polite"></div></div>' + player + stubs +
       jscript('kv-cites', cites_json) +
       '<script>' + kv_js + '</script><script>' + board_scripts + '</script></body></html>')

for a_, b_ in SPLITS.items():
    doc = doc.replace(a_, b_)
OUT = AB + '/ajrakh-complete.html'
open(OUT, 'w', encoding='utf-8').write(doc)
for p in ['hero-dyed-mask.png', 'hero-dyed-mask.webp']:
    if os.path.exists(SP + '/system/img/' + p) and not os.path.exists(AB + '/img/' + p):
        shutil.copy(SP + '/system/img/' + p, AB + '/img/' + p)
print('\n'.join(LOG))
print('sources', NS, counts, 'figs', len(FIGS), 'size', len(doc))
