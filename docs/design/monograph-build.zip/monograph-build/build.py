import sys, re, json, os, shutil, html as H
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from lib import *
from tags import tag_re, element_end, children, inner
from sources import Registry, convert_cites, group_of, norm_url
import cssx

CONS = os.path.dirname(os.path.abspath(__file__))
S = {k: rd(p) for k, p in PATHS.items()}
R = Registry(S)
LOG = []


def must(s, old, new, count=1):
    if old not in s:
        raise Exception('missing: ' + old[:160])
    return s.replace(old, new, count)


def must_re(s, pat, new, count=1, flags=re.S):
    s2, n = re.subn(pat, new, s, count=count, flags=flags)
    if not n:
        raise Exception('missing re: ' + pat[:160])
    return s2


def get(board, pattern, after=0):
    s = S[board]
    a, b = find_el(s, pattern, after)
    anc = [t for n, t in ancestors(s, a) if n not in ('body', 'main', 'html')]
    return s[a:b], anc


def anc_tags(board, pattern, after=0):
    s = S[board]
    a, b = find_el(s, pattern, after)
    return [t for n, t in ancestors(s, a) if n not in ('body', 'main', 'html')]


def el(h, pattern, after=0):
    a, b = find_el(h, pattern, after)
    return h[a:b]


def cut(h, pattern, after=0):
    a, b = find_el(h, pattern, after)
    return h[:a] + h[b:], h[a:b]


ITEMS = []
CHAPTERS = []


class Frag:
    def __init__(self, board, html, anc=None, figboard=None):
        self.board = board
        self.html = html
        self.anc = anc or []
        self.figboard = figboard or board


def cv(board, html):
    return convert_cites(R, 'kv', convert_cites(R, board, html))


def frag(board, html, anc=None, figboard=None):
    return Frag(board, cv(board, html), anc, figboard)


def raw(html):
    return Frag('raw', html, [])


def sechead(num, kicker, title, hid, lede='', margin=True):
    m = '<aside class="margin note" aria-label="Sources in this passage"><ul></ul></aside>' if margin else ''
    return ('<div class="spread railed sec-head"><div class="rail"><span class="numeral">%s</span></div><div class="main">'
            '<p class="chapter-no in-main">%s</p><p class="kicker sec-kicker">%s</p><h2 class="t-h2" id="%s">%s</h2>%s</div>%s</div>') % (num, num, kicker, hid, title, lede, m)


def chapter(cid, num, label, items, short=None):
    CHAPTERS.append(dict(id=cid, num=num, label=label, short=short or label, items=items))


def renumeral(h, old, new):
    h = h.replace('<span class="numeral">%s</span>' % old, '<span class="numeral">%s</span>' % new, 1)
    h = re.sub(r'<p class="chapter-no in-main">[^<]*</p>', '<p class="chapter-no in-main">%s</p>' % new, h, count=1)
    return h


def sk_for(board, url_part):
    for (b, sk), d in R.local.items():
        if b == board and url_part in (d.get('u') or ''):
            return sk
    raise KeyError((board, url_part))


def claim_quotes(board, cid):
    return R.data[board]['claims'].get(cid, [])


def kvq(board, sk, loc, q):
    return [R.alias(board, sk), loc, q]


def kv_cite(cid, keys, label='#'):
    return '<button class="cite" type="button" data-claims="%s" data-n="%s">%s</button>' % (cid, ','.join('%s=%d' % (k, i + 1) for i, k in enumerate(keys)), label)


PC = {
    177057: ('Tyrian purple (PubChem CID 177057)', [('Synonym', 'Tyrian purple'), ('Synonym', "6,6'-Dibromoindigo"), ('Molecular Formula', 'C16H8Br2N2O2')]),
    27284: ('Ferrous cation (PubChem CID 27284)', [('Title', 'Ferrous cation'), ('Molecular Formula', 'Fe+2')]),
    29936: ('Ferric cation (PubChem CID 29936)', [('Title', 'Ferric cation'), ('Molecular Formula', 'Fe+3')]),
    24489: ('Sodium dithionite (PubChem CID 24489)', [('Title', 'Sodium Dithionite'), ('Molecular Formula', 'Na2O4S2')]),
    24437: ('Sodium sulfite (PubChem CID 24437)', [('Title', 'Sodium Sulfite'), ('Molecular Formula', 'Na2O3S')]),
    14798: ('Sodium hydroxide (PubChem CID 14798)', [('Title', 'Sodium Hydroxide'), ('Molecular Formula', 'HNaO')]),
}
for cid_, (t, _) in PC.items():
    R.add_local('kv', 'pc%d' % cid_, dict(t=t, by='PubChem, National Library of Medicine', y=None, r='A', u='https://pubchem.ncbi.nlm.nih.gov/compound/%d' % cid_))


def pcq(*cids):
    out = []
    for c in cids:
        for loc, q in PC[c][1]:
            out.append(['pc%d' % c, loc, q])
    return out


MONGA = 'aj:S20'
IMPART = 'aj:S14'
R.kv_claim('kv:cloth', [kvq('ask', 'aj:S01', q[1], q[2]) for q in claim_quotes('ask', 'ans:L1') if q[0] == 'aj:S01' and ('cotton' in q[2] or 'Silk' in q[2])])
R.kv_claim('kv:coda', [kvq('mb', MONGA, "section 'History repeats itself'", 'Water and good quality water is essential to the survival of Ajrakh')])
R.kv_claim('kv:tyrian', pcq(177057))
R.kv_claim('kv:ironair', [kvq('mb', IMPART, 'paragraph 6', 'These lines oxidise when exposed to air and the harda and develop a black colour.')] + pcq(27284, 29936))
R.kv_claim('kv:lime', [kvq('chem', q[0], q[1], q[2]) for q in claim_quotes('chem', 'q128')] + [kvq('mb', q[0], q[1], q[2]) for q in claim_quotes('mb', 'aj:C073')])
R.kv_claim('kv:hydros', pcq(24489, 14798, 24437))
R.kv_claim('kv:sufian', [kvq('mb', MONGA, "section 'History repeats itself'", 'One of the initial stages is when the cloth is dyed with myrobalan and then washed. If there is even one percent iron in water, the (pale yellow) cloth gets black spots. We tested and found seven percent iron content in the groundwater in Dhamadka,” Sufian explained.'),
                         kvq('mb', MONGA, "section 'History repeats itself'", '“Water and good quality water is essential to the survival of Ajrakh,” Sufian Khatri, who is a ninth-generation Ajrakh craftsman, said.')])
R.kv_claim('kv:sikandar', [kvq('mb', MONGA, "section 'History repeats itself'", '“The water table is going down like never before,” said Sikandar Usman Khatri, an Ajrakh craftsman. “When our family had just moved in here, water would start bubbling at a depth of 200 feet. It was good quality water. But when I had to dig a private borewell for additional water supply for my growing business, the depth was 450 feet,” he added.')])

CHECK = '<svg viewBox="0 0 14 14" aria-hidden="true"><path d="M2.5 7.5 L5.5 10.5 L11.5 3.5" fill="none" stroke="currentColor" stroke-width="1.7"/></svg>'
INF = '<span class="kv-inf">Inferred</span>'


def atoms_table(rows):
    body = ''.join('<tr><th scope="row">%s</th><td>%s</td><td>%s</td><td class="ok">%s<span class="vh">balanced</span></td></tr>' % (a, b, c, CHECK) for a, b, c in rows)
    return ('<table class="atoms"><caption>Count the atoms</caption><thead><tr><th scope="col">Atom</th><th scope="col">Before</th><th scope="col">After</th><th scope="col"><span class="vh">Check</span></th></tr></thead><tbody>' + body + '</tbody></table>')


QSHORT = 'How does Ajrakh work?'
ANSWER_TOC = {1: 'chemistry', 2: 'history', 3: 'made', 4: 'why-kachchh', 5: 'market', 6: 'cloth', 7: 'made'}

head, anc_ans = get('chem', r'<header class="ans-head"')
opener, _ = get('chem', r'<div class="opener"')
QFULL = re.search(r'<span class="q-text" id="q-text">(.*?)</span>', head).group(1)
lede = re.search(r'<p class="t-lede ans-lede">.*?</p>', opener, re.S).group(0)
opener = must(opener, '<p class="kicker">The short answer</p>', '')
opener = must(opener, lede, '')
opener = must_re(opener, r'<div class="actions two">.*?</div>', '')
for n, target in ANSWER_TOC.items():
    opener = re.sub(r'<li><a href="#(?:chem|top)"( aria-current="location")?><b>%d</b>' % n, '<li><a href="#%s"><b>%d</b>' % (target, n), opener, count=1)
opener = must(opener, '<nav class="toc" aria-label="Chapters of this answer"><p class="kicker">In this answer</p>',
              '<nav class="toc kv-toc" aria-label="Sections of this answer"><p class="kicker">The answer in seven sections</p><p class="kv-toc-d">Chemistry, history, overview, geography, economics, design and process. Each opens the chapter of this page that tells it in full.</p>')
ask_s = S['ask']
ua, ub = find_el(ask_s, r'<div class="understood"')
understood = ask_s[ua:ub].replace(' <a class="inline" href="#">Change</a>', '')
opener = must(opener, '</ol></nav>', '</ol></nav>' + understood.replace('class="understood"', 'class="understood kv-understood"'))

mast, anc_mast = get('mb', r'<header class="mast2"')
label = el(mast, r'<div class="label-card mast-label"')
label = must(label, '<h1 class="lc-title">Kutch Ajrakh</h1>', '<p class="lc-title">Kutch Ajrakh</p>')
label = must(label, '<span>Drawn from 20 sources</span>', '<span>Monograph drawn from 20 sources</span>')
label = label.replace('class="label-card mast-label"', 'class="label-card mast-label on-photo kv-open-label"', 1)
mphoto = el(mast, r'<figure class="plate mast2-photo"')
mcap = re.search(r'<figcaption>.*?</figcaption>', mphoto, re.S).group(0)
mimg = re.search(r'<img [^>]*>', mphoto).group(0)
mimg = re.sub(r' style="[^"]*"', '', mimg)
mlede = el(mast, r'<div class="spread mast-lede"')

open_html = ('<header class="kv-open"><div class="kv-wrap kv-open-grid">'
             '<div class="kv-open-q"><p class="kicker kv-open-k"><span>Your question</span><span>Expert answer</span></p>'
             '<h1 class="kv-q">' + QSHORT + '</h1>'
             '<button class="kv-q-more" type="button" aria-expanded="false" aria-controls="kv-q-full">Show the full question</button>'
             '<p class="kv-q-full" id="kv-q-full" hidden><span class="kv-q-l">Asked in full</span>“' + QFULL + '”</p></div>'
             '<div class="kv-open-a"><p class="kicker">The short answer</p>' + cv('chem', lede) +
             '<div class="kv-open-act"><button class="btn primary" type="button" data-listen-open aria-controls="kv-player"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 2.8 L13 8 L4.5 13.2 Z" fill="currentColor"/></svg><span>Listen · <span data-listen-min>7</span> min</span></button>'
             '<button class="btn" type="button" data-kv-save aria-pressed="false">Save</button><button class="btn" type="button" data-kv-goto="kv-cite" data-kv-tab="answer">Cite this answer</button></div>'
             '<p class="kv-open-prov">@@PROV@@<span>Answered 18 Nov 2026</span></p></div>'
             '<figure class="plate kv-open-photo"><div class="kv-open-stage"><div class="ph">' + mimg + '</div>' + label + '</div>' + mcap + '</figure>'
             '</div></header>')
chapter('answer', 0, 'The answer', [frag('mb', open_html, ['<section class="screen" data-aid="craft">']), frag('chem', opener, anc_ans)], short='Answer')

glance, anc_gl = get('mb', r'<section class="chapter" id="glance"')
glance = re.sub(r'<div class="record">.*$', '', glance, flags=re.S)
glance = glance + '</section>' if not glance.rstrip().endswith('</section>') else glance
hero, anc_hero = get('mb', r'<div class="hero"')
hero = remove_el(hero, r'<header class="appbar on-photo"')
hero = remove_el(hero, r'<div class="hero-in"')
hero = must(hero, '<p class="lc-k"><span>Specimen</span><span>Textiles · Hand block printing</span></p>', '<p class="lc-k"><span>Specimen</span><span>The cloth, close up</span></p>')
hero = must(hero, '<p class="lc-name" id="hl-name">Kutch Ajrakh</p>', '<p class="lc-name" id="hl-name">Stars on an indigo ground</p>')
hero = must_re(hero, r'<p class="lc-s">.*?</p>', '<p class="lc-s">Dark eight-pointed stars and white-outlined motifs, printed and dyed by hand. Dip it to see the green of the vat lift from this print, as it does in <a class="inline" href="#fig1"><span class="kv-figref" data-figref="chem:1">Fig. 1</span></a>.</p>')
hero = must_re(hero, r'<ol class="steps vat-steps".*?</ol>\s*', '')
hero = must(hero, '>Play again</button>', '>Dip it again</button>')
hero = must_re(hero, r'<div class="lc-meta">.*?</div>\s*', '')
four, anc_four = get('mb', r'<section class="four"')
four = must_re(four, r'(<p class="agent">Indigo, then air</p><p class="ctext">).*?(</p>)', r'\1Green from the vat, blue in the air: <a class="inline" href="#fig1"><span class="kv-figref" data-figref="chem:1">Fig. 1</span></a>.\2')
four, ckey = cut(four, r'<div class="colour-key"')
cloth_it = ('<div class="wrap kv-cloth-it"><figure class="plate kv-cloth-plate"><div class="ph"><img src="img/ajrak-indigo-dyed-cloth.jpg" width="1280" height="1707" alt="Ajrak print in blue, black and white: an indigo-ground field of star and lattice motifs." loading="lazy"></div>'
            '<figcaption><p class="cap">Ajrak print in blue, black and white: an indigo-ground field of star and lattice motifs.</p><p class="credit">Photo: SMarndi, CC BY-SA 4.0</p></figcaption></figure>'
            '<div class="kv-cloth-t"><p class="kicker">The cloth itself</p><p class="kv-cloth-p"><span class="s">Ajrakh is printed mostly on cotton, in natural dyes; printers buy cotton of 60s to 120s count, by what the cloth will become, and print silk ajrakh to <span class="nw">order.' + kv_cite('kv:cloth', ['ask|aj:S01']) + '</span></span></p>'
            '</div><div class="kv-cloth-t kv-cloth-t2"><p class="kicker">What the colours mean</p>' + ckey + '</div></div>')
chapter('cloth', 1, 'The cloth', [frag('mb', '<div class="wrap kv-mlede">' + mlede + '</div>', ['<section class="screen" data-aid="craft">', '<article>']),
                                  frag('mb', glance, anc_gl), frag('mb', hero, anc_hero), frag('mb', four, anc_four),
                                  Frag('mb', cv('kv', cv('mb', cloth_it)), anc_four)])

made, anc_made = get('pt', r'<section class="sec wrap" id="cloth"')
made = renumeral(made, '3', '2')
proof, _ = get('mb', r'<figure class="proof-wrap"')
mb_dek = re.search(r'<p class="chart-dek">(.*?)</p>', proof, re.S).group(1)
made_dek_old = re.search(r'(<p class="chart-title" id="fig2-t">One cloth, drawn after each stage</p><p class="chart-dek">)(.*?)(</p>)', made, re.S)
MB_DEK_FRAG = mb_dek[mb_dek.find('<span class="s" data-src="aj:S04 aj:S09">'):]
assert MB_DEK_FRAG.startswith('<span')
made = made[:made_dek_old.start(2)] + '@@MBDEK@@' + made[made_dek_old.end(2):]
made_parts = made.split('@@MBDEK@@')
made = made_parts[0] + cv('mb', MB_DEK_FRAG) + made_parts[1]
made = must_re(made, r'(<p class="lc-why"><span class="lk">Why</span>)<span class="s" data-src="S01 S14">Cloth lifted from the indigo vat is bright green at first.*?</span></span>',
               r'\1Green from the vat, blue in the air: the dip is <a class="inline" href="#fig1"><span class="kv-figref" data-figref="chem:1">Fig. 1</span></a>, and its chemistry <a class="inline" href="#rp-blue"><span class="kv-figref" data-figref="chem:2">Fig. 3</span></a>.')
made = made.replace('A textile printing block being carved at the Anokhi Museum, Jaipur: a Jaipur block, not an ajrakh block.',
                    'A textile printing block being carved at the Anokhi Museum, Jaipur, December 2019: a Jaipur block, not an ajrakh block.')
chapter('made', 2, 'How it is made', [frag('pt', made, anc_made)], short='Making')

chem_ch, anc_chem = get('chem', r'<section class="chem-ch" id="chem"')
chem_ch = chem_ch.replace('<span class="numeral">1</span>', '<span class="numeral">3</span>', 1)
chem_ch = chem_ch.replace('<p class="chapter-no in-main">Chapter 1</p><p class="kicker ch-kick">Chemistry</p>', '<p class="chapter-no in-main">3</p><p class="kicker ch-kick">The chemistry</p>', 1)
chem_ch = must_re(chem_ch, r'<span class="s" data-src="a1 a3">Cloth lifted from the indigo vat is bright green and turns blue.*?</span></span>',
                  'The blue that appears in the air in <a class="inline" href="#fig1">Fig. 1</a> is followed here to its molecules, with the black and the red.')
subrail, _ = get('chem', r'<nav class="subrail"')
subrail = re.sub(r'<li><a href="#sources">.*?</li>', '', subrail, flags=re.S)
blue, _ = get('chem', r'<section class="sec" id="blue"')
BOND = 'Each O–H gives up its hydrogen, and the single bond between the halves becomes a double bond.'
blue = must(blue, '<p class="rp-link">The dip and the lift are drawn in', '<p class="rp-bond"><span class="kv-mk" aria-hidden="true"></span>In the structures: ' + BOND + '</p><p class="rp-link">The dip and the lift are drawn in')
blue = must(blue, 'Ringed: the oxygens that lose or gain the two hydrogens.</p>', 'Ringed: the oxygens that lose or gain the two hydrogens. ' + BOND + '</p>')
blue = must_re(blue, r'(three natural vat dyes, with woad and Tyrian <span class="nw">purple\..*?</button></span></span>)',
               r'\1 <span class="s">Tyrian purple is itself an indigo: 6,6′-dibromoindigo, C<sub>16</sub>H<sub>8</sub>Br<sub>2</sub>N<sub>2</sub>O<sub>2</sub>, indigo with two bromine <span class="nw">atoms.' + kv_cite('kv:tyrian', ['pc177057']) + '</span></span>')
red, _ = get('chem', r'<section class="sec" id="red"')
black, _ = get('chem', r'<section class="sec" id="black"')
black = re.sub(r'<div class="pull"><blockquote>.*?</div>', '', black, flags=re.S)


def span_of(board, text_start):
    src = S[board]
    i = src.find(text_start)
    assert i > 0, text_start
    a = src.rfind('<span class="s"', 0, i)
    return src[a:element_end(src, a)]


frater = cv('rm', span_of('rm', 'Frater names the dyes'))
edw = cv('rm', span_of('rm', 'Edwards writes that the synthetic form of madder'))
mad1 = cv('mb', span_of('mb', 'Indian madder holds high amounts of alizarin'))
mad2 = cv('mb', span_of('mb', 'alizarin still needs a mordant such as alum'))
ri = red.find('<p class="sec-intro')
re_ = red.find('</p>', ri)
red = red[:re_] + ' ' + mad1 + ' ' + mad2 + ' ' + edw + red[re_:]
bi = black.find('<p class="sec-intro')
be_ = black.find('</p>', bi)
black = black[:be_] + ' ' + frater + black[be_:]
IRON_EQ = ('<div class="eq kv-eq-ox" role="group" aria-label="Four iron(II) ions plus oxygen plus four hydrogen ions give four iron(III) ions plus two water">'
           '<div class="eq-line"><span class="side"><span class="sp"><b>4 Fe<sup>2+</sup></b><small>iron(II), in the paste</small></span><span class="op">+</span><span class="sp"><b>O<sub>2</sub></b><small>oxygen, from the air</small></span><span class="op">+</span><span class="sp"><b>4 H<sup>+</sup></b><small>acid</small></span></span>'
           '<span class="side prod"><span class="op arrow">→</span><span class="sp"><b>4 Fe<sup>3+</sup></b><small>iron(III)</small></span><span class="op">+</span><span class="sp"><b>2 H<sub>2</sub>O</b><small>water</small></span></span></div>'
           '<div class="eq-foot">' + atoms_table([('Fe', '4', '4'), ('O', '2', '2'), ('H', '4', '2 × 2 = 4'), ('Charge', '4 × 2 + 4 = +12', '4 × 3 = +12')]) +
           '<div class="eq-notes"><p class="eq-note">Formulas from the KalaVigyan compound library; atoms and charge balance.</p></div></div></div>'
           '<p class="eq-none">Then iron(III) binds the phenol groups of tannic acid into the iron–tannin black. A complex forms, so this step is written as species, without coefficients. ' + INF + '</p>')
black = must(black, '<p class="eq-none">Written as the source names it: iron and tannic acid give a deep, fast chocolate-black.</p>', IRON_EQ)
black = must_re(black, r'(<h4>Iron meets tannic acid and turns black</h4><p class="rp-p">.*?</p>)',
                r'\1<p class="rp-bond kv-gloss">Read “oxidises with the tannic acid” this way: the air is the oxidant. The printed lines “oxidise when exposed to air and the harda and develop a black <span class="nw">colour”' + kv_cite('kv:ironair', ['mb|' + IMPART, 'pc27284', 'pc29936']) + '</span>: the paste’s iron(II) becomes iron(III), which the tannic acid holds as the black. ' + INF + '</p>')
white, _ = get('chem', r'<section class="sec" id="white"')
white = must_re(white, r'<details class="differs"><summary><span>Sources differ: how many times the <i>saaj</i> is repeated</span></summary>.*?</details>', '')
model, _ = get('chem', r'<section class="sec" id="model"')
model = model.replace(' srcdoc="', ' data-srcdoc="', 1)
mats, _ = get('chem', r'<section class="sec" id="materials"')
mats = must_re(mats, r'(Gum and lime are the resist materials ajrakh printers prefer <span class="nw">today\.)<button class="cite"[^>]*>.*?</button>',
               lambda m: m.group(1) + kv_cite('kv:lime', [R.alias('chem', q[0]) for q in claim_quotes('chem', 'q128')][:1] + [R.alias('mb', 'aj:S05'), R.alias('mb', 'aj:S09')]))
differ, _ = get('chem', r'<section class="sec" id="differ"')
bn, _ = get('chem', r'<div class="bn-spec"')
hyp_note = ('<div class="kv-hyp wrap"><div class="kv-hyp-in"><p class="kicker">The source’s own words for step 2</p>'
            '<p class="kv-hyp-t">A formula-complete step that does not balance is shown, not hidden, with the hypothesis mark.</p></div>' + bn + '</div>')
chain, anc_chain = get('ask', r'<section class="chain"')
chain = re.sub(r'<div class="ch-eq">.*?</p></div>', '', chain, flags=re.S)
chain = chain.replace('<p class="ch-note">Written in neutral form, as the KalaVigyan compound library writes it.</p>', '')
chain = must(chain, '<p class="ch-inf">', '<p class="ch-t"><a class="inline" href="#rp-blue" data-rp-step="rp-blue:1">Fig. 3, step 1</a></p><p class="ch-inf">')
chain = must(chain, '<p class="ch-k"><b>4</b>In the vat</p>', '<p class="ch-k"><b>4</b>In the vat</p><p class="ch-t"><a class="inline" href="#rp-blue" data-rp-step="rp-blue:3">Fig. 3, step 3</a></p>')
HYDROS = ('<div class="ch-eq kv-hydros"><p class="kv-eq-k">The hydros vat, balanced</p><div class="eq-line eq-sm" role="group" aria-label="Indigo plus sodium dithionite plus four sodium hydroxide gives the sodium salt of leucoindigo plus two sodium sulfite plus two water">'
          '<span class="side"><span class="sp"><b>C<sub>16</sub>H<sub>10</sub>N<sub>2</sub>O<sub>2</sub></b><small>indigo</small></span><span class="grp"><span class="op">+</span><span class="sp"><b>Na<sub>2</sub>S<sub>2</sub>O<sub>4</sub></b><small>hydros</small></span></span><span class="grp"><span class="op">+</span><span class="sp"><b>4 NaOH</b><small>caustic soda</small></span></span></span>'
          '<span class="side"><span class="grp"><span class="op">→</span><span class="sp"><b>C<sub>16</sub>H<sub>10</sub>N<sub>2</sub>Na<sub>2</sub>O<sub>2</sub></b><small>leucoindigo, as its sodium salt</small></span></span><span class="grp"><span class="op">+</span><span class="sp"><b>2 Na<sub>2</sub>SO<sub>3</sub></b><small>sulfite</small></span></span><span class="grp"><span class="op">+</span><span class="sp"><b>2 H<sub>2</sub>O</b></span></span></span></div>'
          '<p class="eq-count"><span class="ok">' + CHECK + '</span>Each side: C 16 · H 14 · N 2 · Na 6 · O 10 · S 2</p></div>'
          '<p class="ch-inf"><span class="ev-inferred">The sources name the reagents, sodium hydrosulphite and caustic soda. Balanced, each dithionite gives up two electrons as it becomes two sulfites, and the alkali holds leucoindigo as its soluble sodium <span class="nw">salt.' + kv_cite('kv:hydros', ['pc24489', 'pc14798', 'pc24437']) + '</span></span> <span class="ev-tag inferred">Inferred</span></p>')
chain = re.sub(r'(<li class="ch"><p class="ch-k"><b>4</b>In the vat</p>.*?)(</li>)', lambda m: m.group(1) + HYDROS + m.group(2), chain, count=1, flags=re.S)
chain = chain.replace('href="#vat">See Fig. 1</a>', 'href="#fig1">See Fig. 1</a>')
CHELATE = el(S['rm'], r'<figure class="fig chemfig redfig" id="fig3-en"')
CHELATE = re.sub(r'<p class="chart-dek">.*?</p>', '<p class="chart-dek">The 2D structures, as the compound library draws them: where the ring closes on aluminium, and the hydroxyl purpurin adds.</p>', CHELATE, count=1, flags=re.S)
CHELATE = must(CHELATE, '<p class="chart-title" id="f3-t-en">Alizarin and purpurin, the reds in madder</p>', '<p class="chart-title" id="f3-t-en">Alizarin closes a six-member ring on aluminium</p>')
CHELATE = re.sub(r'<p class="cs-t"><span class="s" data-sid="f3.chelate">.*?</p>', '', CHELATE, count=1, flags=re.S)
CHELATE = remove_el(CHELATE, r'<div class="whites"')
chapter('chemistry', 3, 'The chemistry', [
    frag('chem', chem_ch + subrail + blue, anc_chem),
    frag('ask', '<div class="kv-chain kv-wrap">' + chain + '</div>', ['<section class="screen">'], figboard='chem'),
    Frag('chem', cv('kv', cv('chem', hyp_note + red)), anc_chem),
    frag('rm', '<div class="wrap kv-chelate">' + CHELATE + '</div>', ['<section class="screen" data-screen="1" data-aid="cite">']),
    Frag('chem', cv('kv', cv('chem', black + white + model + mats + differ)), anc_chem),
], short='Chemistry')

why, anc_why = get('pt', r'<section class="sec why" id="why"')
osm = re.search(r'<p class="src-line">(Stream course, villages and the Rann: OpenStreetMap contributors.*?)</p>', why, re.S).group(1)
why = must(why, '<p class="src-line">' + osm + '</p></figure>', '</figure>')
ws_cards = [m.start() for m in re.finditer(r'<li class="ws-card', why)]
why = why[:ws_cards[3]] + '</ol><p class="src-line kv-src-13">' + osm + '</p><ol class="ws ws-more">' + why[ws_cards[3]:]
WELL = ('<svg class="well-svg kv-well" data-fit viewBox="0 0 300 236" role="img" aria-label="Depth drawn to scale: water once rose at 200 feet below ground at Ajrakhpur; a later private borewell reached 450 feet">'
        '<rect x="44" y="26" width="256" height="204" fill="var(--sunk)"/><rect x="44" y="26" width="256" height="204" fill="url(#strata)"/><rect x="44" y="24.5" width="256" height="1.5" fill="var(--ink-1)"/>'
        + ''.join('<line x1="36" x2="44" y1="%.1f" y2="%.1f" stroke="var(--ink-3)"/><text class="kv-ax" x="33" y="%.1f" text-anchor="end">%s</text>' % (26 + d * 0.4, 26 + d * 0.4, 26 + d * 0.4 + 3.5, ('%d ft' % d) if d == 500 else str(d)) for d in range(0, 501, 100)) +
        '<rect x="150" y="26" width="40" height="180" fill="var(--raised)" stroke="var(--ink-1)" stroke-width="1.2"/><rect class="w-water" x="151" y="192" width="38" height="13" fill="var(--map-river)" opacity=".9" data-w/>'
        '<path d="M134 106 H206" stroke="var(--ink-1)" stroke-width="1.2" stroke-dasharray="4 3"/><path d="M134 206 H206" stroke="var(--ink-1)" stroke-width="1.8"/>'
        '<g class="wl"><text x="128" y="20" text-anchor="end">ground</text><text x="212" y="103">200 ft</text><text x="212" y="117" class="kv-wl2">water once</text><text x="212" y="203">450 ft</text><text x="212" y="217" class="kv-wl2">borewell now</text></g></svg>')
why = must_re(why, r'<svg class="well-svg" data-fit viewBox="0 0 300 236".*?</svg>', WELL)
why = must(why, '<h3>The wells go deeper</h3>', '<h3>The wells go deeper</h3><p class="kv-scale">Depth drawn to scale, 0 to 500 ft.</p>')
why = must_re(why, r'<span class="s" data-src="S20">At Ajrakhpur water once rose at a depth of 200 feet, but an artisan&#x27;s later private borewell had to reach 450 <span class="nw">feet\..*?</button></span></span>',
              '<span class="s">At Ajrakhpur water once rose at a depth of 200 feet, but the private borewell Sikandar Usman Khatri later dug had to reach 450 <span class="nw">feet.' + kv_cite('kv:sikandar', ['mb|' + MONGA]) + '</span></span>')
why = why.replace('an artisan explained to <span class="nw">Mongabay.', 'Sufian Khatri explained to <span class="nw">Mongabay.')
tmp, _ = get('mb', r'<figure class="tmp-fig"')
s_mb = S['mb']
j = s_mb.find('Fig. <b>8</b>')
dfa = s_mb.rfind('<figure', 0, j)
dist = s_mb[dfa:element_end(s_mb, dfa)]
banni_i = S['rm'].find('banni-grasslands')
bfa = S['rm'].rfind('<figure', 0, banni_i)
banni = S['rm'][bfa:element_end(S['rm'], bfa)]
pt_c035 = R.data['pt']['claims'].get('C035', [])
banni_q = ('<blockquote class="kv-pull"><p>“The Dhamadka River was the only one in Kachchh that used to flow in the opposite direction. Usually the rivers originated in the Banni grasslands and flowed southwards. This one would empty itself into the Banni.”</p>'
           '<footer><span class="s">Khamir, <i>Khatris &amp; Community</i>, “Voices across Kachchh: <span class="nw">Dhamadka”' + '<button class="cite" type="button" data-claims="C035" data-n="S10=1">1</button></span></span></footer></blockquote>')
trio_anc = anc_tags('mb', r'<div class="trio"')
chapter('why-kachchh', 4, 'Why Kachchh', [
    frag('pt', why, anc_why),
    frag('mb', '<div class="trio kv-trio">' + tmp + dist + '</div>', trio_anc),
    frag('rm', '<div class="kv-banni wrap">' + banni + '<div class="kv-banni-q">' + cv('pt', banni_q) + '</div></div>', []),
])

time_, anc_time = get('pt', r'<section class="sec wrap" id="time"')
time_ = renumeral(time_, '2', '5')
time_, pk = cut(time_, r'<figure class="plate pt-plate margin-plate"')
pk = pk.replace('class="plate pt-plate margin-plate"', 'class="plate kv-pk"', 1)
pk = must(pk, '<p class="cap">', '<p class="cap kv-look">Look at the trefoils carved on the shawl.</p><p class="cap">')
time_ = must(time_, '</p></div><aside class="margin note"', '</p>' + pk + '</div><aside class="margin note"')
time_ = must_re(time_, r'(<div data-evc="0" hidden>.*?)<figure class="plate tl-card-plate">.*?</figure>', r'\1<p class="kv-see"><a class="inline" href="#history">The bust is pictured at the head of this chapter.</a></p>')
time_ = must_re(time_, r'(<li class="tl-li" data-li="0">.*?)<figure class="plate ">.*?</figure>', r'\1')
chapter('history', 5, 'History and trade', [frag('pt', time_, anc_time)], short='History')

market, anc_mk = get('pt', r'<section class="sec wrap" id="market"')
market = renumeral(market, '5', '6')
wa, wb = find_el(market, r'<div class="wif" data-comp="lab"')
lab = market[wa:wb]
market = market[:wa] + market[wb:]
ia = market.find('<h3>Who still prints it</h3>')
wsa = market.rfind('<div class="mk-block">', 0, ia)
who = market[wsa:element_end(market, wsa)]
market = market[:wsa] + market[element_end(market, wsa):]
pa = market.find('img/ajrakh-artisan-holding-cloth.jpg')
pfa = market.rfind('<figure', 0, pa)
artisan = market[pfa:element_end(market, pfa)]
market = market[:pfa] + market[element_end(market, pfa):]
chapter('market', 6, 'Market and GI', [frag('pt', market, anc_mk)], short='Market and GI')

lab = remove_el(lab, r'<div class="vatfig" data-vat')
la_, lb_ = find_el(lab, r'<div class="lab-same"')
lab = lab[:la_] + remove_el(lab[la_:lb_], r'<div class="eq" role="group"') + lab[lb_:]
lab = must_re(lab, r'<p><span class="s" data-src="S01 S14">In either vat the cloth comes out bright green.*?</p>', '<p>The dip is the same in either vat: <a class="inline" href="#fig1"><span class="kv-figref" data-figref="chem:1">Fig. 1</span></a>.</p>')
lab = must_re(lab, r'<p><span class="s" data-src="S01">Alizarin, among the first chemical red dyes, was invented in 1868.*?</p>', '<p>First made in a laboratory in 1868: <a class="inline" href="#history">the 1868 entry of <span class="kv-figref" data-figref="pt:1">Fig. 17</span></a>.</p>')
bpa, bpb = find_el(lab, r'<div class="lab-panel" data-exp="blue"')
bp = lab[bpa:bpb]
moved = ''
for pat in [r'<div class="forms" data-forms="natural"', r'<div class="forms" data-forms="synthetic"', r'<div class="lab-same"']:
    bp, piece = cut(bp, pat)
    moved += piece
va, vb = find_el(bp, r'<div class="lab-vis"')
bp = bp[:vb - len('</div>')] + '<div class="kv-lab-more">' + moved + '</div></div>' + bp[vb:]
lab = lab[:bpa] + bp + lab[bpb:]
lab_title = re.search(r'<p class="chart-title">(.*?)</p>', lab).group(1)
lab = lab.replace('<p class="chart-title">%s</p>' % lab_title, '', 1)
wi_head = sechead('7', 'What if', lab_title, 'whatif-h', '<p class="t-lede">Three choices the sources describe, each shown with what they say follows.</p>')
lab = re.sub(r'<p class="chart-dek">Three choices the sources describe, each shown with what they say follows.</p>', '', lab, count=1)
chapter('what-if', 7, 'What if', [frag('pt', '<section class="sec wrap kv-whatif" aria-labelledby="whatif-h">' + wi_head + lab + '</section>', [t for t in anc_mk if 'id="market"' not in t])])

voice, anc_voice = get('sa', r'<figure class="voice"')
voice = must(voice, '<p class="voice-credit"><span class="s">A Kutch ajrakh artisan, speaking to Mongabay India, <span class="nw">2019.',
             '<p class="voice-credit"><span class="s">Sufian Khatri, a ninth-generation ajrakh craftsman, speaking to Mongabay India, <span class="nw">2019.')
voice = re.sub(r'(<p class="voice-credit"><span class="s">Sufian Khatri.*?)<button class="cite"[^>]*>.*?</button>', lambda m: m.group(1) + kv_cite('kv:sufian', ['mb|' + MONGA]), voice, count=1, flags=re.S)
artisan = must(artisan, 'src="img/ajrakh-artisan-holding-cloth.jpg" width="1280" height="1707"', 'src="img/ajrakh-artisan-hand-and-border.jpg" width="720" height="720"')
artisan = must(artisan, 'alt="An artisan holding up a large printed ajrakh with a dense central field and several borders."', 'alt="An artisan’s hand at the edge of a printed ajrakh, beside its bands of border print."')
artisan = must_re(artisan, r'<p class="cap"><span class="s" data-src="S13 S15">An ajrakh artisan from Kutch holds up a printed ajrakh, its central field framed by <span class="nw">borders\.',
                  '<p class="cap"><span class="s" data-src="S13 S15">A printer’s hand at the edge of an ajrakh: the borders that frame its central <span class="nw">field.')
artisan = artisan.replace('Visdaviva, CC BY-SA 3.0, via Wikimedia Commons</a>', 'Visdaviva, CC BY-SA 3.0, via Wikimedia Commons</a>, cropped')
people_head = sechead('8', 'People and voices', 'The Khatris who print it, in their own words', 'people-h')
chapter('people', 8, 'People and voices', [
    frag('pt', '<section class="sec wrap kv-people" aria-labelledby="people-h">' + people_head + '<div class="mk-grid kv-people-grid"><div>' + who + '</div><div class="kv-people-ph">' + artisan + '</div></div></section>', [t for t in anc_mk if 'id="market"' not in t]),
    Frag('sa', cv('kv', cv('sa', '<div class="kv-voice kv-wrap">' + voice + '</div>')), []),
], short='People')

end_main, anc_end = get('rm', r'<div class="end-main"')
eb = inner(end_main)
blocks = [eb[a:b] for a, b in children(eb)]
quiz_block, ask_block, related_block = blocks[0], blocks[1], blocks[2]
related_block = related_block.replace('<h2>Related crafts</h2>', '<h3>Related crafts</h3>')
KIN_SW = [('6', '<i>pa</i>, the alum'), ('3', '<i>rekh</i>, the outline'), ('10', '<i>rang</i>, red on alum'), ('11', '<i>minakari</i>, madder red')]
ki = [0]


def kin_sw(m):
    t, lab_ = KIN_SW[ki[0] % 4]
    ki[0] += 1
    return ('<div class="tplate kv-kin-sw" data-tile="%s"><svg class="kv-sw-svg" viewBox="0 0 300 150" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><rect x="-50" y="-50" width="400" height="250" fill="url(#KVTILE-%s)"/><rect x="-50" y="-50" width="400" height="250" fill="url(#KVWEAVE)"/></svg>'
            '<span class="kv-sw-l">Ajrakh after %s</span>' % (t, t, lab_)) + m.group(1) + '</div>'


related_block = re.sub(r'<a class="tplate g-textile" href="#cite">(.*?)</a>', kin_sw, related_block, flags=re.S)
related_block = related_block.replace('Four monographs that share a material or a method with Kutch Ajrakh, each with the sentence that links them.',
                                      'Four monographs that share a material or a method with Kutch Ajrakh, each with the sentence that links them. Each swatch is the Ajrakh stage they share, drawn as in <span class="kv-figref" data-figref="pt:2">Fig. 2</span>.')

atlas = jdata(S['mb'], 'atlas-index')
WRONG = re.compile(r'diazotization|soda lime silica|tamarind and lime', re.I)
ss_parts = []
for key in ('indigo', 'madder', 'alum', 'lime', 'mordant', 'tannin'):
    c = atlas['concepts'][key]
    if not any(r[0] == 'Kutch Ajrakh' for r in c['rows']):
        continue
    aj = [r for r in c['rows'] if r[0] == 'Kutch Ajrakh'][0]
    others = [r for r in c['rows'] if r[0] != 'Kutch Ajrakh']
    wrong = [r for r in others if WRONG.search(re.sub(r'<[^>]+>', '', r[4] or ''))]
    others = [r for r in others if (r[4] or '').strip() and r not in wrong]
    others.sort(key=lambda r: -r[3])
    nmono = c['n'] - sum(1 for r in wrong if not any(r2[0] == r[0] for r2 in others))
    chips = ''.join('<span class="kv-co">%s <b>%d</b></span>' % (H.escape(x[0]), x[1]) for x in c['cooc'])

    def row(r):
        return '<li class="res-row"><span class="res-name kv-res-name">%s</span><span class="res-meta">%s · %s · named in %d cited sentence%s</span><p class="res-s">%s</p></li>' % (
            H.escape(r[0]), H.escape(r[1]), H.escape(r[2]), r[3], '' if r[3] == 1 else 's', r[4])
    lead = row(others[0]) if others else ''
    rest = ''.join(row(r) for r in others[1:])
    more = ('<details class="kv-more"><summary><span class="kv-more-o">Show all %d</span><span class="kv-more-c">Show fewer</span></summary><ol class="res-list">%s</ol></details>' % (len(others), rest)) if rest else ''
    ss_parts.append('<div class="res-group kv-ss" id="ss-%s"><div class="res-concept"><h3>%s</h3><p>Named in the cited sentences of %d of the 23 monographs; in %d of Kutch Ajrakh’s.</p><p class="cooc"><span>Named in the same monographs</span>%s</p></div><ol class="res-list">%s</ol>%s</div>' % (key, c['label'], nmono, aj[3], chips, lead, more))
shared = '<div class="kv-shared"><h3 class="kv-sub-h">The same science, named in other monographs</h3><p class="kv-sub-d">Six ideas that Kutch Ajrakh’s cited sentences share with other crafts in the atlas. Each leads with the craft that names it most; Show all lists every craft and its sentence.</p><div class="results kv-results">' + ''.join(ss_parts) + '</div></div>'
kin_head = sechead('9', 'Kin crafts and shared science', 'Four crafts share its materials and methods', 'kin-h')
CODA = ('<section class="kv-coda" aria-label="Coda"><svg class="kv-coda-cloth" viewBox="0 0 1200 520" preserveAspectRatio="xMidYMid slice" aria-hidden="true" focusable="false"><rect x="-100" y="-100" width="1400" height="720" fill="url(#KVTILE-11)"/><rect x="-100" y="-100" width="1400" height="720" fill="url(#KVWEAVE)"/></svg>'
        '<div class="kv-wrap kv-coda-in"><figure class="label-card kv-coda-card"><p class="lc-k"><span>Coda</span><span>In the printer’s words</span></p>'
        '<blockquote class="kv-coda-q"><p>“Water and good quality water is essential to the survival of Ajrakh.”</p></blockquote>'
        '<figcaption class="kv-coda-c"><span class="s">Sufian Khatri, a ninth-generation ajrakh craftsman, to Mongabay India, <span class="nw">2019.' + kv_cite('kv:coda', ['mb|' + MONGA]) + '</span></span></figcaption>'
        '<p class="kv-coda-n">The cloth behind is drawn as it leaves stage 11, <i>minakari</i>, in <a class="inline" href="#made"><span class="kv-figref" data-figref="pt:2">Fig. 2</span></a>: every colour this page has followed, from the river to the vat.</p></figure></div></section>')
chapter('kin', 9, 'Kin crafts', [
    frag('pt', '<section class="sec wrap" aria-labelledby="kin-h">' + kin_head + '</section>', [t for t in anc_mk if 'id="market"' not in t]),
    frag('rm', '<div class="kv-related">' + related_block + '</div>', anc_end),
    frag('mb', shared, ['<section class="screen" data-aid="atlas">', '<div class="wrap">']),
    Frag('mb', cv('kv', CODA), []),
], short='Kin crafts')

howcite, anc_hc = get('mb', r'<section class="howcite"')
howcite = howcite.replace('<h2 class="t-h2" id="hc-h">', '<h3 class="t-h2" id="hc-h">').replace('Every numeral opens a source.</h2>', 'Every numeral opens a source.</h3>')
howcite = howcite.replace('<b><span class="mk a" aria-hidden="true">a</span>7</b>', '<b><span class="mk a" aria-hidden="true">a</span><span data-gnum="https://www.sahapedia.org/ajrakh-introduction-0"></span></b>')
howcite = howcite.replace('<figcaption><b>8</b><strong>Ajrakh: From Caste Dress to Catwalk</strong>', '<figcaption><b><span data-gnum="https://irep.ntu.ac.uk/id/eprint/29181/1/PubSub6671_Edwards.pdf"></span></b><strong>Ajrakh: From Caste Dress to Catwalk</strong>')
cite_rm, _ = get('rm', r'<div class="cite-box" id="cite-box"')
cite_rm = cite_rm.replace('id="cite-box"', 'id="kv-cite-answer"', 1)
cite_rm = cite_rm.replace(QFULL, QSHORT)
cite_rm = must(cite_rm, '<p class="cb-h">Cite this answer</p>', '')
cite_mb, _ = get('mb', r'<div class="cite-box"')
cite_mb = re.sub(r'<p class="cb-h">[^<]*</p>', '', cite_mb, count=1)
lang_demo, anc_lang = get('rm', r'<div class="lang-demo" id="lang-demo"')
la, lb = find_el(lang_demo, r'<div class="lang-panel" data-pop-box data-lang-panel="en"')
lang_demo = lang_demo[:la] + '<div class="lang-panel" data-lang-panel="en" lang="en" data-ui-lang="en" hidden><p class="kv-lang-en">English is the answer as written: <a class="inline" href="#answer">the opening</a> and every chapter of this page.</p></div>' + lang_demo[lb:]
lang_demo = must(lang_demo, '<button type="button" aria-pressed="false" data-lang="en" lang="en">English</button><button type="button" aria-pressed="true" data-lang="hi" lang="hi">', '<button type="button" aria-pressed="true" data-lang="en" lang="en">English</button><button type="button" aria-pressed="false" data-lang="hi" lang="hi">')
lang_demo = must_re(lang_demo, r'<span class="t-caption" id="lang-status" role="status">.*?</span>', '<span class="t-caption" id="lang-status" role="status">English · the answer as written</span>')
lang_demo = must(lang_demo, '<div class="lang-panel" data-lang-panel="en" lang="en" data-ui-lang="en" hidden>', '<div class="lang-panel" data-lang-panel="en" lang="en" data-ui-lang="en">')
lang_demo = must(lang_demo, '<div class="lang-panel" data-pop-box data-lang-panel="hi" lang="hi" data-ui-lang="hi">', '<div class="lang-panel" data-pop-box data-lang-panel="hi" lang="hi" data-ui-lang="hi" hidden>')
lang_demo = lang_demo.replace('English is the answer as written: <a class="inline" href="#answer">the opening</a> and every chapter of this page.', 'English is the answer as written, from <a class="inline" href="#answer">the opening</a> on. Choose हिन्दी or اردو to read the opening and its first section in that language, with the same numerals, the same margin and the same figure.')
lang_demo = lang_demo.replace('<h1 class="q-title', '<h3 class="q-title').replace('</span></h1>', '</span></h3>')
lang_demo = remove_el(lang_demo, r'<div class="ur-block ur-excerpt"')
lang_demo = lang_demo.replace('16 स्रोतों से', '@@NSRC@@ स्रोतों से').replace('16 ذرائع سے', '@@NSRC@@ ذرائع سے')
lang_demo = lang_demo.replace('A&#8239;7</span>', 'A&#8239;@@NA@@</span>').replace('B&#8239;7</span>', 'B&#8239;@@NB@@</span>').replace('C&#8239;2</span>', 'C&#8239;@@NC@@</span>')
lang_demo = re.sub(r'(<span class="rel-strip" role="img" aria-label=")([^"]*)(")', lambda m: m.group(1) + re.sub(r'16', '@@NSRC@@', m.group(2)).replace(' 7 ', ' @@NA@@ ', 1).replace(' 7 ', ' @@NB@@ ', 1).replace(' 2 ', ' @@NC@@ ', 1) + m.group(3), lang_demo)
lang_demo = lang_demo.replace('data-goto="cite-box"', 'data-kv-goto="kv-cite" data-kv-tab="answer"')
lang_demo = lang_demo.replace('data-listen="1"', 'data-listen-open').replace('href="#cite"', 'href="#cloth"')
lang_demo = re.sub(r'(Listen · |सुनें · |سنیے · )7( min| मिनट| منٹ)', lambda m: m.group(1) + '<span data-listen-min>7</span>' + m.group(2), lang_demo)
teen, anc_teen = get('sa', r'<section class="twin-col" data-level="teen"')
comic, anc_comic = get('sa', r'<ol class="comic"')
alt = ('<div class="kv-alt"><div class="kv-alt-h"><h3 class="kv-sub-h">Two more ways to read this answer</h3><p class="kv-sub-d">The same cited sentences, for a reader of 14 to 17 and as a six-panel story. Every picture is drawn by AI for this answer and says so; the reader and the printer are invented characters.</p></div>'
       '<div class="kv-alt-grid"><details class="kv-alt-teen"><summary><span class="kv-alt-s">The student version</span><span class="kv-alt-d">For a reader of 14 to 17 · open to read</span></summary>' + teen + '</details><div class="kv-alt-comic">' + comic + '</div></div></div>')
listen_block = ('<div class="end-block kv-listen-block"><h3 class="kv-sub-h">Listen</h3><p class="kv-sub-d">The short answer and the opening of every chapter, read aloud. The sentence being read is marked and the page follows it; Previous and Next move a sentence at a time.</p>'
                '<div class="kv-actions"><button class="kv-btn" type="button" data-listen-open aria-controls="kv-player"><svg viewBox="0 0 16 16" aria-hidden="true"><path d="M4.5 2.8 L13 8 L4.5 13.2 Z" fill="currentColor"/></svg><span>Listen · <span data-listen-min>7</span> min</span></button></div></div>')
quiz_block = quiz_block.replace('<h2>Check yourself</h2>', '<h3>Check yourself</h3>')
ask_block = ask_block.replace('<h2>Ask next</h2>', '<h3>Ask next</h3>')
ask_block = ask_block.replace('Five questions that pick up where the sources stop.', 'Six questions that pick up where the sources stop.')
extra_q = 'Why does lime discharge alum, chemically, in the outline resist?'
first_li = re.search(r'<li><a href="#cite" data-ask=".*?</li>', ask_block, re.S).group(0)
new_li = re.sub(r'data-ask="[^"]*"', 'data-ask="%s"' % extra_q, first_li)
new_li = re.sub(r'<span class="aq">.*?</span>', '<span class="aq">%s</span>' % extra_q, new_li)
ask_block = ask_block.replace('</ul></div>', new_li + '</ul></div>')
ask_block = ask_block.replace('href="#cite"', 'href="#reading"')
reading_head = sechead('10', 'Reading tools', 'How to read, hear, test and cite this page', 'reading-h')
CITE_OPEN = ('<div class="kv-wrap"><section class="kv-cite" id="kv-cite" aria-labelledby="kv-cite-h"><div class="kv-cite-top"><h3 class="kv-sub-h" id="kv-cite-h">Cite this page</h3>'
             '<div class="kv-tabs" role="tablist" aria-label="What to cite"><button type="button" role="tab" id="kv-ct-a" aria-controls="kv-cp-a" aria-selected="true" data-kv-ct="answer">This answer</button>'
             '<button type="button" role="tab" id="kv-ct-m" aria-controls="kv-cp-m" aria-selected="false" tabindex="-1" data-kv-ct="monograph">The monograph</button></div></div>'
             '<div class="kv-cp" id="kv-cp-a" role="tabpanel" aria-labelledby="kv-ct-a">')
CITE_MID = '</div><div class="kv-cp" id="kv-cp-m" role="tabpanel" aria-labelledby="kv-ct-m" hidden>'
CITE_END = '</div></section></div>'
chapter('reading', 10, 'Reading tools', [
    frag('pt', '<section class="sec wrap" aria-labelledby="reading-h">' + reading_head + '</section>', [t for t in anc_mk if 'id="market"' not in t]),
    frag('mb', howcite, anc_hc),
    frag('rm', '<div class="wrap kv-readtools"><div class="end-wrap"><div class="end-main">' + listen_block + quiz_block + ask_block + '</div></div></div>', ['<section class="screen" data-aid="end">']),
    raw(CITE_OPEN),
    frag('rm', '<div class="kv-cites">' + cite_rm + '</div>', ['<section class="screen" data-aid="end">']),
    raw(CITE_MID),
    frag('mb', '<div class="kv-cites kv-cites-mb">' + cite_mb + '</div>', ['<section class="screen" data-aid="craft">']),
    raw(CITE_END),
    frag('rm', '<div class="kv-lang"><h3 class="kv-sub-h">In हिन्दी and اردو</h3>' + lang_demo + '</div>', anc_lang),
    frag('sa', '<div class="kv-wrap">' + alt + '</div>', []),
], short='Reading')

gen_strip, anc_gen = get('rm', r'<div class="gen-strip"')
gen_wrap, anc_gw = get('rm', r'<div class="gen-wrap"')
gen_wrap = remove_el(gen_wrap, r'<div class="side-phone"')
gen_wrap = remove_el(gen_wrap, r'<div class="doc">', count=5)
gen_wrap = re.sub(r'<script type="application/json" id="film-subs">.*?</script>', '', gen_wrap, flags=re.S)
gen_strip = must(gen_strip, '<p class="gen-state" id="gen-state">Writing section 7 of 7<span id="gen-sub">Sections 1 to 6 are written and illustrated</span></p>',
                 '<p class="gen-state" id="gen-state">Answer written<span id="gen-sub">7 sections, 7 illustrations, 1 video and the film</span></p>')
gen_strip = must(gen_strip, '<i class="writing" style="--w:67%"></i>', '<i class="done"></i>')
gen_strip = must(gen_strip, '<button class="btn primary sm" type="button" id="gen-go">Continue writing</button><button class="btn sm" type="button" id="gen-reset">Start over</button>',
                 '<button class="btn primary sm" type="button" id="gen-reset">Watch it being made</button><button class="btn sm" type="button" id="gen-go" disabled hidden>Continue writing</button>')
gen_strip = gen_strip.replace('<div class="actions" data-count="2">', '<div class="actions" data-count="1">', 1)
g7a, g7b = find_el(gen_wrap, r'<article class="gsec" data-n="7"')
g7 = gen_wrap[g7a:g7b]
g7 = must(g7, 'data-state="writing" data-total="3" data-shown="2" aria-busy="true"', 'data-state="done" data-total="3" data-shown="3"')
g7 = must_re(g7, r'<span class="gsec-st">.*?Writing</span>', lambda m: '<span class="gsec-st">' + CHECK + 'Written</span>')
g7 = g7.replace('<span class="s pending" ', '<span class="s" ')
g7 = must(g7, '<div class="ai-art is-drawing" style="--p:58%"', '<div class="ai-art"')
g7 = must(g7, '<span class="ai-job-t">Drawing · 58%</span><span class="meter"><b style="width:58%"></b></span>', '<span class="ai-job-t">Drawing</span><span class="meter"><b style="width:0%"></b></span>')
g7 = must(g7, 'data-name="kutch-ajrakh-answer-section-7-illustration" disabled>', 'data-name="kutch-ajrakh-answer-section-7-illustration">')
gen_wrap = gen_wrap[:g7a] + g7 + gen_wrap[g7b:]
gen_wrap = must(gen_wrap, '7 scenes, one a section · 0:56 · 6 of 7 scenes ready', '7 scenes, one a section · 0:56 · ready')
gen_wrap = gen_wrap.replace('<i class="ready cur"></i><i class="ready"></i><i class="ready"></i><i class="ready"></i><i class="ready"></i><i class="ready"></i><i></i>', '<i class="ready cur"></i><i class="ready"></i><i class="ready"></i><i class="ready"></i><i class="ready"></i><i class="ready"></i><i class="ready"></i>')
gen_wrap = must(gen_wrap, 'The film can be saved when scene 7 arrives.', '')
gen_wrap = must(gen_wrap, 'id="film-dl" disabled', 'id="film-dl"')
gen_wrap = must_re(gen_wrap, r'<li data-job="7"><span class="th drawing">', '<li data-job="7"><span class="th">')
gen_wrap = must_re(gen_wrap, r'(<li data-job="7">.*?<span class="js">).*?(</span></span></li>)', lambda m: m.group(1) + CHECK + 'Ready' + m.group(2))
gen_wrap = must_re(gen_wrap, r'(<li data-job="film">.*?<span class="js">).*?(</span></span></li>)', lambda m: m.group(1) + CHECK + 'Ready, 0:56' + m.group(2))
gen_wrap = must_re(gen_wrap, r'(<figure class="ai ai-only" data-sec="1" data-kind="video" id="vid">.*?<figcaption class="ai-cap"><span>)<span class="s" data-sid="p0b399a40611b\.4">.*?</span></span>',
                   r'\1The dip of <a class="inline" href="#fig1"><span class="kv-figref" data-figref="chem:1">Fig. 1</span></a>, moving.')
ai_defs_i = S['rm'].find('id="ai-defs"')
ai_defs = ''
if ai_defs_i > 0:
    da = S['rm'].rfind('<svg', 0, ai_defs_i)
    ai_defs = S['rm'][da:element_end(S['rm'], da)]
media_head = sechead('11', 'Pictures, video and film', 'Each section arrives with its picture, and the answer becomes a film', 'media-h',
                     '<p class="t-lede">For Expert answers, made while the answer is written, from its cited sentences, and labelled AI where they appear. Watch it being made replays the writing, section by section.</p>', margin=False)
chapter('media', 11, 'Pictures, video and film', [
    frag('pt', '<section class="sec wrap" aria-labelledby="media-h">' + media_head + '</section>', [t for t in anc_mk if 'id="market"' not in t]),
    frag('rm', gen_strip + '<div class="wrap">' + gen_wrap + '</div>' + (ai_defs if ai_defs and ai_defs not in gen_wrap else ''), anc_gen),
], short='Media')

prog, anc_prog = get('ask', r'<nav class="prog"')
prog = prog.replace('<span class="pg-d" data-pg="reading"></span>', '<span class="pg-d">@@NSRC@@ sources read</span>').replace('<span class="pg-d" data-pg="writing"></span>', '<span class="pg-d">The opening and seven sections</span>')
prog = re.sub(r'<li data-a="(\d+)" data-b="(\d+)">', r'<li class="is-done" data-kv-a="\1" data-kv-b="\2">', prog)
prog = prog.replace('<p class="vh" role="status" data-prog-status></p>', '<p class="vh" role="status" data-kv-made-status></p>')
sources_head = sechead('12', 'Sources', 'Every source, numbered once', 'sources-h',
                       '<p class="t-lede">Numbered as they first appear on this page, the same in every chapter. Press a source to light the sentences it supports.</p>', margin=False)
MADE = ('<div class="kv-made-how" data-kv-made><div class="kv-made-top"><h3 class="kv-sub-h">How this answer was made</h3>'
        '<button class="btn sm" type="button" data-kv-made-play>Watch it being made</button></div>' + understood.replace('class="understood"', 'class="understood kv-understood"') + prog +
        '<div class="kv-made-grid"><div class="kv-made-col"><p class="kicker">Sources, as they were read</p><ol class="kv-made-src" data-kv-made-src>@@MADESRC@@</ol></div>'
        '<div class="kv-made-col"><p class="kicker">Sections, as they were written</p><ol class="kv-made-sec" data-kv-made-sec>@@MADESEC@@</ol></div></div>'
        '<p class="kv-made-ready" data-kv-made-ready>The answer is ready: the opening and seven sections, from @@NMAIN@@ sources.</p></div>')
chapter('sources', 12, 'Sources', [
    frag('pt', '<section class="sec wrap" aria-labelledby="sources-h">' + sources_head + '</section>', [t for t in anc_mk if 'id="market"' not in t]),
    frag('ask', MADE, ['<section class="screen rs" data-aid="research">', '<div class="in">']),
    frag('rm', '@@SOURCES@@', ['<section class="screen" data-aid="cite">', '<div class="wrap">']),
    frag('pt', '@@CREDITS@@', ['<div class="screen">']),
])

json.dump({'chapters': [(c['id'], c['num'], c['label']) for c in CHAPTERS]}, open(CONS + '/chapters.json', 'w'))
exec(open(CONS + '/build2.py', encoding='utf-8').read())
