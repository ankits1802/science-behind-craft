import re, json, html as H
from tags import tag_re, element_end, VOID

SP = 'C:/Users/anujk/AppData/Local/Temp/claude/4532a1d13aec9931/00206b47-abd6-4e32-9463-9fb5c0bb9b5a/scratchpad'
AB = SP + '/answer-boards'

PATHS = {
    'chem': AB + '/chemistry.html',
    'pt': AB + '/place-and-time.html',
    'rm': AB + '/reading-and-media.html',
    'mb': SP + '/system/master-board.html',
    'ask': AB + '/ask-and-research.html',
    'sa': AB + '/students-and-artisans.html',
}


def rd(p):
    return open(p, encoding='utf-8').read()


def jdata(s, id_):
    m = re.search(r'<script type="application/json" id="' + re.escape(id_) + r'">(.*?)</script>', s, re.S)
    return json.loads(m.group(1)) if m else None


def find_el(s, pattern, after=0):
    rx = re.compile(pattern)
    pos = after
    while True:
        m = rx.search(s, pos)
        if not m:
            raise Exception('not found: ' + pattern)
        i = s.rfind('<', 0, m.start() + 1)
        tm = tag_re.match(s, i)
        if tm and not tm.group(1) and tm.end() > m.start():
            return i, element_end(s, i)
        pos = m.end()


def ancestors(s, idx):
    stack = []
    pos = s.find('<body')
    while pos < idx:
        m = tag_re.search(s, pos)
        if not m or m.start() >= idx:
            break
        pos = m.end()
        g = m.group(0)
        if g.startswith('<!--'):
            continue
        name = m.group(2).lower()
        if m.group(1):
            for k in range(len(stack) - 1, -1, -1):
                if stack[k][0] == name:
                    del stack[k:]
                    break
            continue
        if name in ('script', 'style', 'textarea', 'title'):
            e = s.lower().find('</' + name, m.end())
            pos = s.find('>', e) + 1
            continue
        if name in VOID or m.group(4):
            continue
        if name == 'svg':
            pos = element_end(s, m.start())
            continue
        stack.append((name, g))
    return stack


ATTR_RE = re.compile(r'([^\s=/>]+)(?:\s*=\s*("[^"]*"|\'[^\']*\'|[^\s>]+))?')


def parse_attrs(starttag):
    m = re.match(r'<([a-zA-Z][\w:-]*)', starttag)
    body = starttag[m.end():].rstrip('>').rstrip('/')
    out = []
    for a in ATTR_RE.finditer(body):
        k = a.group(1)
        v = a.group(2)
        if v is not None and v[:1] in '"\'':
            v = v[1:-1]
        out.append((k, v))
    return m.group(1), out


def build_tag(name, attrs):
    parts = [name]
    for k, v in attrs:
        if v is None:
            parts.append(k)
        else:
            parts.append('%s="%s"' % (k, v.replace('"', '&quot;')))
    return '<' + ' '.join(parts) + '>'


def set_attr(starttag, key, val):
    name, attrs = parse_attrs(starttag)
    attrs = [(k, v) for k, v in attrs if k != key]
    if val is not None:
        attrs.append((key, val))
    return build_tag(name, attrs)


def remove_el(s, pattern, after=0, count=1):
    for _ in range(count):
        try:
            a, b = find_el(s, pattern, after)
        except Exception:
            break
        s = s[:a] + s[b:]
    return s


def replace_el(s, pattern, new, after=0):
    a, b = find_el(s, pattern, after)
    return s[:a] + new + s[b:]


def text_of(h):
    t = re.sub(r'<script.*?</script>|<style.*?</style>', '', h, flags=re.S)
    t = re.sub(r'<button class="(?:cite|kcite)"[^>]*>.*?</button>', '', t, flags=re.S)
    t = re.sub(r'<[^>]+>', ' ', t)
    t = H.unescape(t)
    return re.sub(r'\s+', ' ', t).strip()
